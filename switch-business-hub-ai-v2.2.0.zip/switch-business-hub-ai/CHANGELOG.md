# Changelog

All notable changes to Switch Business Hub AI will be documented in this file.

## [2.2.0] - 2026-02-18

### 🧠 AI + Document Flow Improvements

- Added dedicated **AI Order Assistant tab** (AI is no longer shown across all tabs)
- Fixed pack-based AI pricing logic (e.g. "100 Cards" now defaults to 1 pack, avoiding inflated totals)
- AI now marks catalog-only conversations with default **Create Invoice** behavior
- AI quote modal now allows both actions:
  - **Create Invoice** for catalog items
  - **Request Quote** for custom/exception requests

### 🛒 Checkout & Invoice Behavior

- Enabled **guest checkout** for cart invoices (name + WhatsApp, no forced account creation)
- Cart checkout remains direct invoice flow
- Guest orders can still generate invoice references for tracking

### 🎨 Premium UI / Layout Updates

- Switched to pure black app base theme and removed constrained-page look
- Added viewport-filling layout behavior for shortcode pages
- Improved premium bottom nav styling
- Added dedicated AI panel to keep app sections cleaner

### 🏭 Supplier + Catalog Expansion

- Added supplier-backed catalog entries with 75% markup model:
  - https://www.printabilitypress.co.za/
  - https://emdeebranding.co.za/
  - https://displaymania.co.za/
- Added new supplier products in print, apparel and display segments

### 🖼️ Generated Catalog Images

- Added generated branded product mockup image fallback for products without uploaded images
- Every product now has a visual display image (custom upload takes priority)

### 👑 Super Admin + Demo Data

- Added default super-admin defaults:
  - Name: Switch Graphics
  - WhatsApp: 0681474232
  - Email: tinashe@switchgraphics.co.za
  - Password: Nuclear@20#
- Added frontend **Super Admin Dashboard** panel:
  - Status updates for recent quotes/invoices
  - Quick variation price editor (no WordPress backend required for these edits)
- Installer now seeds demo quote + invoice records for layout/track testing

## [2.1.0] - 2026-02-18

### 🚀 AI Quote Flow Overhaul

- Rebuilt guided AI conversation for print/signage/design quoting
- Added wedding welcome board guidance with A1 size/material options (Correx, Forex, Perspex)
- Added custom-job fallback estimates when a product is not in the catalog
- AI now asks design-vs-own-file, delivery, due date and notes before finalizing
- Quote payload now carries richer item detail (SKU, design fee, delivery fee, file note)

### 🛍️ Product + Pricing Improvements

- Expanded catalog with additional print products and wedding signage options
- Added baseline 75% markup normalization where cost prices are available
- Added core service items:
  - Design service from R350
  - Custom jobs at R350/hour
  - Delivery from R160
- Added product image resolver so admin-assigned product images display in shop cards

### 📦 Order / Invoice / Tracking Fixes

- Fixed shop invoice creation to respect quantity correctly
- Updated invoice numbering to `INV-SBH0001` format
- Tracking now works by invoice/SBH reference and checks quote/invoice records first
- Improved tracking output for pending vs verifying payment status

### 👤 Customer Portal UX + Reliability

- Header branding now supports full business name + reg/CSD lines
- Top branding text is styled in orange, per brand request
- Contact panel now uses business options for phone/WhatsApp/email/address
- Banking panel colors improved for better visibility
- Quote submission now:
  - uses logged-in customer details automatically
  - includes AI transcript
  - supports optional multi-file upload
- Added chat history persistence endpoints and logged-in sync support

### 🛠️ Admin Enhancements

- Product manager now supports image selection/upload directly in product edit form
- Orders view now shows richer item details (SKU, design/delivery fee breakdown)
- Orders view now displays AI chat transcript when available

## [1.8.0] - 2026-01-13

### 🚀 Major Features

#### Complete AI Rebuild
- **Conversational Quote Builder**: AI guides customers step-by-step
- **Design Service Integration**: AI asks about design needs (+R350)
- **Auto-Fill Quote Form**: All AI-collected info fills the form
- **Chat Transcript Attached**: Conversation attached to quotes

#### Product Catalog with SKUs
- 25+ Product categories with variants
- Each variant has unique SKU (e.g., BC-500-DS)
- 75% markup pricing from wholesale rates
- Design Service: from R350
- Custom Jobs: R350 per hour
- Delivery: from R160

#### Customer Dashboard
- Dashboard with stats for logged-in users
- Quote and invoice history
- Guest users: Direct AI chat access

#### Company Branding
- Full company details in header
- Bank details in Contact tab
- Invoice format: INV-SBH01

### 🔧 Improvements

- ✅ Contact tab: Phone, email, WhatsApp links
- ✅ Track order: Invoice number only (not email)
- ✅ Product images: Upload via Settings > Products
- ✅ Quote form: Auto-fills from AI conversation

### 📦 Products (75% markup)

**Printing:** Business Cards R175-R613, Flyers R140-R788, Posters R61-R1050
**Signage:** Banners R158-R1138, Pull-Ups R613-R1575, X-Banners R490-R665
**Wedding:** Welcome Boards R210-R1488, Seating Charts R315-R1138
**Apparel:** T-Shirts R123-R201, Golf Shirts R210-R315, Hoodies R315-R525
**Vehicle:** Door Decals R1400+, Half Wraps R3500+, Full Wraps R7875+
**Services:** Design R350+, Custom R350/hr, Delivery R160+

---

## [1.7.0] - 2026-01-12
- Initial conversational AI
- WhatsApp integration

## [1.6.0] - 2026-01-11  
- Premium UI redesign
- Service catalog

---
**Switch Graphics (Pty) Ltd** | 068 147 4232 | www.switchgraphics.co.za
