<?php
/**
 * Switch Graphics Product Catalog
 * 
 * All 108 products from spreadsheet with 50% markup
 * 
 * @package SwitchBusinessHub
 * @version 1.8.2
 */

if (!defined('ABSPATH')) exit;

class SBHA_Products {
    
    /**
     * Get all products from catalog
     */
    public static function get_all() {
        return array(
            // ========== BUSINESS CARDS ==========
            'standard_business_cards' => array(
                'name' => 'Standard Business Cards',
                'category' => 'business_cards',
                'price' => 225.00,
                'original' => 150.00,
                'variations' => 'Single/Double Sided, Matte/Gloss/Soft Touch Lamination, Rounded Corners Optional',
                'details' => 'High-quality 350gsm stock, full colour printing',
                'description' => '🔥 MAKE YOUR FIRST IMPRESSION COUNT! Premium business cards that demand attention.',
                'source' => 'ThePrintShop'
            ),
            'premium_business_cards' => array(
                'name' => 'Premium Business Cards',
                'category' => 'business_cards',
                'price' => 265.65,
                'original' => 177.10,
                'variations' => 'Various quantities: 100-5000+, Single/Double Sided, Multiple finishes',
                'details' => '400gsm luxury stock, digital full colour, lamination options',
                'description' => '⭐ ELEVATE YOUR BRAND INSTANTLY! These aren\'t just business cards - they\'re conversation starters.',
                'source' => 'MediaMafia'
            ),
            'plastic_business_cards' => array(
                'name' => 'Plastic Business Cards',
                'category' => 'business_cards',
                'price' => 326.03,
                'original' => 217.35,
                'variations' => 'Quantities: 100-1000, Frosted/Clear options',
                'details' => 'Durable PVC plastic, waterproof, tear-resistant',
                'description' => '💎 UNFORGETTABLE FIRST IMPRESSIONS! Sleek, modern plastic cards that WON\'T bend, tear, or fade.',
                'source' => 'MediaMafia'
            ),
            
            // ========== FLYERS & LEAFLETS ==========
            'a5_flyers' => array(
                'name' => 'A5 Flyers',
                'category' => 'flyers',
                'price' => 187.50,
                'original' => 125.00,
                'variations' => 'A5 (148x210mm), 100-10,000 qty, Single/Double Sided',
                'details' => 'Full colour on 150gsm gloss or matt paper',
                'description' => '📢 GET YOUR MESSAGE OUT THERE! Eye-catching flyers that cut through the noise.',
                'source' => 'ThePrintShop'
            ),
            'budget_a5_flyers' => array(
                'name' => 'Budget A5 70g Flyers',
                'category' => 'flyers',
                'price' => 1.04,
                'original' => 0.69,
                'variations' => 'Per flyer, min 200, Single/Double sided',
                'details' => '70g bond paper, economical bulk printing',
                'description' => '💰 MAXIMUM IMPACT, MINIMUM SPEND! Perfect for mass distribution.',
                'source' => 'MediaMafia'
            ),
            'a4_flyers' => array(
                'name' => 'A4 Flyers',
                'category' => 'flyers',
                'price' => 211.86,
                'original' => 141.24,
                'variations' => 'A4 (210x297mm), Various quantities',
                'details' => 'Full colour digital print, multiple paper weights',
                'description' => '🎯 BIG MESSAGE, BIG IMPACT! A4 flyers that command attention.',
                'source' => 'MediaMafia'
            ),
            'a6_flyers' => array(
                'name' => 'A6 Flyers',
                'category' => 'flyers',
                'price' => 142.50,
                'original' => 95.00,
                'variations' => 'A6 compact size, 100-5000 qty',
                'details' => 'Postcard size, perfect for handouts',
                'description' => '✨ POCKET-SIZED POWER! Compact flyers perfect for events and handouts.',
                'source' => 'ImpressOnline'
            ),
            'dl_flyers' => array(
                'name' => 'DL Flyers',
                'category' => 'flyers',
                'price' => 165.00,
                'original' => 110.00,
                'variations' => 'DL (99x210mm), fits standard envelopes',
                'details' => 'Ideal for mail campaigns and rack displays',
                'description' => '📬 PERFECT FOR DIRECT MAIL! Sleek DL format that slides right into envelopes.',
                'source' => 'ImpressOnline'
            ),
            'folded_leaflets' => array(
                'name' => 'Folded Leaflets',
                'category' => 'flyers',
                'price' => 483.00,
                'original' => 322.00,
                'variations' => 'Various fold types: Bi-fold, Tri-fold, Z-fold, Gate fold',
                'details' => 'Multiple paper weights, various sizes',
                'description' => '📖 TELL YOUR COMPLETE STORY! Professional folded leaflets.',
                'source' => 'MediaMafia'
            ),
            
            // ========== POSTERS ==========
            'paper_posters' => array(
                'name' => 'Paper Posters',
                'category' => 'posters',
                'price' => 15.00,
                'original' => 10.00,
                'variations' => 'A0-A4 sizes, 10-100+ qty',
                'details' => 'Full colour, gloss or satin finish',
                'description' => '🎨 MAKE WALLS TALK! Vibrant, eye-catching posters.',
                'source' => 'ThePrintShop'
            ),
            'poster_printing' => array(
                'name' => 'Poster Printing',
                'category' => 'posters',
                'price' => 8.85,
                'original' => 5.90,
                'variations' => 'Multiple sizes: A4 to A0+, per poster',
                'details' => 'High resolution digital print, various finishes',
                'description' => '🌟 STUNNING VISUAL IMPACT! Crisp, vivid colours.',
                'source' => 'MediaMafia'
            ),
            'large_format_photo_prints' => array(
                'name' => 'Large Format Photo Prints',
                'category' => 'posters',
                'price' => 45.00,
                'original' => 30.00,
                'variations' => 'Custom sizes up to 1.5m wide',
                'details' => 'Photo quality on premium papers',
                'description' => '📸 BRING YOUR IMAGES TO LIFE! Museum-quality large format prints.',
                'source' => 'ThePrintShop'
            ),
            'rigid_posters' => array(
                'name' => 'Rigid Posters',
                'category' => 'posters',
                'price' => 127.50,
                'original' => 85.00,
                'variations' => 'A0-A3, mounted on board',
                'details' => 'Foam board or PVC backing for durability',
                'description' => '💪 BUILT TO LAST! Rigid posters for permanent displays.',
                'source' => 'ImpressOnline'
            ),
            
            // ========== BANNERS ==========
            'pvc_banners' => array(
                'name' => 'PVC Banners',
                'category' => 'banners',
                'price' => 258.75,
                'original' => 172.50,
                'variations' => 'Custom sizes from 1m², eyelets included',
                'details' => '440gsm PVC, weatherproof, hemmed edges',
                'description' => '🚀 ADVERTISE ANYWHERE, ANY WEATHER! Tough, vibrant banners.',
                'source' => 'MediaMafia'
            ),
            'pvc_banner_2x3m' => array(
                'name' => 'PVC Banner 2m x 3m',
                'category' => 'banners',
                'price' => 1080.00,
                'original' => 720.00,
                'variations' => 'Standard 2x3m size',
                'details' => 'Heavy duty PVC, reinforced eyelets',
                'description' => '🎪 GIANT IMPACT FOR EVENTS! Perfect for maximum visibility.',
                'source' => 'MediaMafia'
            ),
            'pvc_banner_2x5m' => array(
                'name' => 'PVC Banner 2m x 5m',
                'category' => 'banners',
                'price' => 1638.75,
                'original' => 1092.50,
                'variations' => '2x5m large format',
                'details' => 'Premium PVC, full colour print',
                'description' => '🏆 GO BIG OR GO HOME! Massive banner for maximum exposure.',
                'source' => 'MediaMafia'
            ),
            'pullup_banners_econo' => array(
                'name' => 'Pull-Up Banners (Econo)',
                'category' => 'banners',
                'price' => 603.75,
                'original' => 402.50,
                'variations' => '850mm x 2000mm, includes stand',
                'details' => 'Retractable banner with carry case',
                'description' => '⚡ INSTANT PROFESSIONAL PRESENCE! Set up in seconds.',
                'source' => 'MediaMafia'
            ),
            'executive_pullup_banner' => array(
                'name' => 'Executive Pull-Up Banner',
                'category' => 'banners',
                'price' => 603.75,
                'original' => 402.50,
                'variations' => '850mm x 2000mm, premium stand',
                'details' => 'Heavy-duty retractable mechanism',
                'description' => '👔 THE CORPORATE CHOICE! Premium pull-up banner.',
                'source' => 'MediaMafia'
            ),
            'x_frame_banners' => array(
                'name' => 'X-Frame Banners',
                'category' => 'banners',
                'price' => 1147.50,
                'original' => 765.00,
                'variations' => '1600mm x 650mm with frame',
                'details' => 'Lightweight X-frame display',
                'description' => '🎯 VERSATILE & PORTABLE! Perfect for exhibitions.',
                'source' => 'ThePrintShop'
            ),
            'budget_x_frame_banners' => array(
                'name' => 'Budget X-Frame Banners',
                'category' => 'banners',
                'price' => 621.00,
                'original' => 414.00,
                'variations' => '600x1600mm, black back PVC',
                'details' => 'Economy X-frame with quality print',
                'description' => '💰 PROFESSIONAL DISPLAY ON A BUDGET!',
                'source' => 'MediaMafia'
            ),
            
            // ========== SIGNAGE ==========
            'correx_boards' => array(
                'name' => 'Correx/Corrugated Plastic',
                'category' => 'signage',
                'price' => 115.50,
                'original' => 77.00,
                'variations' => 'A3 to A0 sizes, various thicknesses',
                'details' => 'Lightweight, waterproof corrugated plastic',
                'description' => '🏠 ESTATE AGENT FAVOURITE! Durable outdoor signage.',
                'source' => 'MediaMafia'
            ),
            'real_estate_boards' => array(
                'name' => 'Real Estate Boards',
                'category' => 'signage',
                'price' => 46.58,
                'original' => 31.05,
                'variations' => 'Standard real estate sizes',
                'details' => 'Durable corrugated plastic',
                'description' => '🏡 SELL PROPERTIES FASTER! Professional estate agent boards.',
                'source' => 'MediaMafia'
            ),
            'abs_signage' => array(
                'name' => 'ABS Signage',
                'category' => 'signage',
                'price' => 69.00,
                'original' => 46.00,
                'variations' => 'A5 to A1 sizes',
                'details' => 'Rigid ABS plastic board',
                'description' => '✨ PROFESSIONAL INDOOR SIGNAGE! Clean, modern look.',
                'source' => 'MediaMafia'
            ),
            'foamboard_prints' => array(
                'name' => 'Foamboard Prints',
                'category' => 'signage',
                'price' => 127.50,
                'original' => 85.00,
                'variations' => 'A4 to A0, various thicknesses',
                'details' => 'Lightweight foam core board',
                'description' => '🎨 PERFECT FOR PRESENTATIONS! Lightweight display boards.',
                'source' => 'ImpressOnline'
            ),
            'chromadek_signs' => array(
                'name' => 'Chromadek Sign Boards',
                'category' => 'signage',
                'price' => 77.62,
                'original' => 51.75,
                'variations' => 'Various sizes available',
                'details' => 'Metal composite board, weatherproof',
                'description' => '🏢 BUILT FOR OUTDOORS! Durable metal signage.',
                'source' => 'MediaMafia'
            ),
            'acrylic_signs' => array(
                'name' => 'Acrylic Signs',
                'category' => 'signage',
                'price' => 448.50,
                'original' => 299.00,
                'variations' => 'Custom sizes and shapes',
                'details' => 'Clear or coloured acrylic',
                'description' => '💎 PREMIUM LOOK! Sleek acrylic signage.',
                'source' => 'ImpressOnline'
            ),
            
            // ========== MUGS & DRINKWARE ==========
            'personalised_mugs' => array(
                'name' => 'Personalised Mugs',
                'category' => 'mugs',
                'price' => 90.00,
                'original' => 60.00,
                'variations' => 'Standard 11oz ceramic mug',
                'details' => 'Full wrap sublimation print',
                'description' => '☕ PERFECT GIFT! Custom printed ceramic mugs.',
                'source' => 'ThePrintShop'
            ),
            'magic_colour_change_mug' => array(
                'name' => 'Magic Colour-Change Mug',
                'category' => 'mugs',
                'price' => 127.50,
                'original' => 85.00,
                'variations' => 'Heat-activated reveal',
                'details' => 'Reveals image with hot liquid',
                'description' => '🎩 MAGIC IN A MUG! Surprise reveal with hot drinks.',
                'source' => 'ThePrintShop'
            ),
            'branded_mugs' => array(
                'name' => 'Branded Mugs',
                'category' => 'mugs',
                'price' => 89.70,
                'original' => 59.80,
                'variations' => 'Various styles, bulk quantities',
                'details' => 'Corporate branding options',
                'description' => '🏢 CORPORATE GIFTING! Branded mugs for your team.',
                'source' => 'MediaMafia'
            ),
            
            // ========== CALENDARS ==========
            'wall_calendars' => array(
                'name' => 'Wall Calendars',
                'category' => 'calendars',
                'price' => 16.82,
                'original' => 11.21,
                'variations' => 'A3/A4 sizes, various designs',
                'details' => 'Full colour, wire-bound',
                'description' => '📅 YEAR-ROUND BRANDING! Custom wall calendars.',
                'source' => 'MediaMafia'
            ),
            'tent_calendars' => array(
                'name' => 'Tent Calendars',
                'category' => 'calendars',
                'price' => 26.40,
                'original' => 17.60,
                'variations' => 'Desk tent style',
                'details' => 'Stands on desk, monthly view',
                'description' => '📆 DESKTOP ESSENTIAL! Practical desk calendars.',
                'source' => 'MediaMafia'
            ),
            'a5_flip_tent_calendars' => array(
                'name' => 'A5 Flip Tent Calendars',
                'category' => 'calendars',
                'price' => 267.38,
                'original' => 178.25,
                'variations' => 'Premium flip style',
                'details' => 'A5 size, premium finish',
                'description' => '✨ PREMIUM DESK CALENDAR! Executive quality.',
                'source' => 'MediaMafia'
            ),
            'wall_flip_calendars' => array(
                'name' => 'Wall Flip Calendars',
                'category' => 'calendars',
                'price' => 220.92,
                'original' => 147.28,
                'variations' => 'Wire-bound wall mount',
                'details' => 'Full colour, 12 months',
                'description' => '🗓️ CLASSIC WALL CALENDAR! Professional quality.',
                'source' => 'MediaMafia'
            ),
            'freight_calendars' => array(
                'name' => 'Freight Calendars',
                'category' => 'calendars',
                'price' => 215.62,
                'original' => 143.75,
                'variations' => '3-tier freight style',
                'details' => 'Traditional business calendar',
                'description' => '📊 TRADITIONAL STYLE! Classic freight calendars.',
                'source' => 'MediaMafia'
            ),
            'calendar_magnets' => array(
                'name' => 'Calendar Magnets',
                'category' => 'calendars',
                'price' => 132.00,
                'original' => 88.00,
                'variations' => 'Business card size',
                'details' => 'Magnetic backing, full year',
                'description' => '🧲 STICK AROUND ALL YEAR! Fridge calendar magnets.',
                'source' => 'MediaMafia'
            ),
            
            // ========== STICKERS & LABELS ==========
            'sticker_printing' => array(
                'name' => 'Sticker Printing',
                'category' => 'stickers',
                'price' => 37.95,
                'original' => 25.30,
                'variations' => 'Custom sizes and shapes',
                'details' => 'Vinyl or paper stickers',
                'description' => '🎉 STICK YOUR BRAND EVERYWHERE! Custom stickers.',
                'source' => 'MediaMafia'
            ),
            'uv_dtf_stickers' => array(
                'name' => 'UV DTF Stickers',
                'category' => 'stickers',
                'price' => 207.00,
                'original' => 138.00,
                'variations' => 'Various sizes',
                'details' => 'UV printed, durable finish',
                'description' => '🌟 PREMIUM UV STICKERS! Vibrant, long-lasting.',
                'source' => 'MediaMafia'
            ),
            'roll_labels' => array(
                'name' => 'Roll Labels',
                'category' => 'stickers',
                'price' => 270.00,
                'original' => 180.00,
                'variations' => 'Custom sizes, per roll',
                'details' => 'Product labeling, bulk quantities',
                'description' => '📦 LABEL YOUR PRODUCTS! Professional roll labels.',
                'source' => 'ThePrintShop'
            ),
            'water_bottle_labels' => array(
                'name' => 'Water Bottle Labels',
                'category' => 'stickers',
                'price' => 258.75,
                'original' => 172.50,
                'variations' => 'Standard bottle wrap sizes',
                'details' => 'Waterproof, wrap-around',
                'description' => '💧 BRAND YOUR BOTTLES! Custom water bottle labels.',
                'source' => 'MediaMafia'
            ),
            'licence_disk_stickers' => array(
                'name' => 'Licence Disk Stickers',
                'category' => 'stickers',
                'price' => 384.68,
                'original' => 256.45,
                'variations' => 'Standard licence disc size',
                'details' => 'Windscreen compatible',
                'description' => '🚗 ADVERTISE IN CARS! Licence disc stickers.',
                'source' => 'MediaMafia'
            ),
            
            // ========== STAMPS ==========
            'self_inking_stamps' => array(
                'name' => 'Self-Inking Rubber Stamps',
                'category' => 'stamps',
                'price' => 313.10,
                'original' => 208.73,
                'variations' => 'Various sizes from 14x38mm to 60x90mm',
                'details' => 'Pre-inked, thousands of impressions',
                'description' => '📝 STAMP YOUR AUTHORITY! Professional rubber stamps.',
                'source' => 'MediaMafia'
            ),
            'commissioner_stamp' => array(
                'name' => 'Commissioner of Oaths Stamp',
                'category' => 'stamps',
                'price' => 975.00,
                'original' => 650.00,
                'variations' => 'Official commissioner stamp',
                'details' => 'Legal compliant format',
                'description' => '⚖️ OFFICIAL STAMPS! Commissioner of Oaths.',
                'source' => 'ThePrintShop'
            ),
            
            // ========== CANVAS & ART ==========
            'canvas_prints' => array(
                'name' => 'Canvas Prints',
                'category' => 'canvas',
                'price' => 157.50,
                'original' => 105.00,
                'variations' => 'From 20x20cm to 90x120cm',
                'details' => 'Gallery wrapped, ready to hang',
                'description' => '🖼️ GALLERY QUALITY! Canvas prints for your walls.',
                'source' => 'ThePrintShop'
            ),
            'acrylic_desktop_print' => array(
                'name' => 'Acrylic Desktop Print',
                'category' => 'canvas',
                'price' => 300.00,
                'original' => 200.00,
                'variations' => 'Various desktop sizes',
                'details' => 'Crystal clear acrylic',
                'description' => '💎 DESK STATEMENT PIECE! Acrylic photo prints.',
                'source' => 'ThePrintShop'
            ),
            'acrylic_wall_prints' => array(
                'name' => 'Acrylic Wall Prints',
                'category' => 'canvas',
                'price' => 313.50,
                'original' => 209.00,
                'variations' => 'A4 to large custom sizes',
                'details' => 'HD print behind acrylic',
                'description' => '✨ MODERN WALL ART! Stunning acrylic prints.',
                'source' => 'ImpressOnline'
            ),
            
            // ========== BOOKS & BINDING ==========
            'hardcover_photobooks' => array(
                'name' => 'Hardcover Photobooks',
                'category' => 'books',
                'price' => 731.40,
                'original' => 487.60,
                'variations' => '20 pages, A4/A5/30x30',
                'details' => 'Premium hardcover binding',
                'description' => '📚 CHERISH YOUR MEMORIES! Premium photo books.',
                'source' => 'MediaMafia'
            ),
            'black_cover_photobooks' => array(
                'name' => 'Black Cover Photobooks',
                'category' => 'books',
                'price' => 432.00,
                'original' => 288.00,
                'variations' => 'A4/A5/30x30, 20 pages standard',
                'details' => 'Elegant black cover',
                'description' => '📖 ELEGANT PHOTO ALBUMS! Black cover photobooks.',
                'source' => 'MediaMafia'
            ),
            'duplicate_ncr_books' => array(
                'name' => 'Duplicate NCR Books',
                'category' => 'books',
                'price' => 637.50,
                'original' => 425.00,
                'variations' => 'A4/A5, 50 sets per book',
                'details' => 'Carbonless copy paper',
                'description' => '📋 DUPLICATE INVOICES! NCR invoice/receipt books.',
                'source' => 'ThePrintShop'
            ),
            'triplicate_ncr_books' => array(
                'name' => 'Triplicate NCR Books',
                'category' => 'books',
                'price' => 712.50,
                'original' => 475.00,
                'variations' => 'A4/A5, 50 sets per book',
                'details' => '3-part carbonless copies',
                'description' => '📋 TRIPLE COPIES! NCR books for multiple records.',
                'source' => 'ThePrintShop'
            ),
            'booklet_printing' => array(
                'name' => 'Booklet & Brochure Printing',
                'category' => 'books',
                'price' => 375.00,
                'original' => 250.00,
                'variations' => 'Various sizes and page counts',
                'details' => 'Saddle-stitched or perfect bound',
                'description' => '📚 PROFESSIONAL BOOKLETS! Company profiles & catalogs.',
                'source' => 'ThePrintShop'
            ),
            'a5_notebooks' => array(
                'name' => 'A5 Notebooks',
                'category' => 'books',
                'price' => 603.75,
                'original' => 402.50,
                'variations' => 'Custom cover, 100+ pages',
                'details' => 'Wire or perfect bound',
                'description' => '📓 BRANDED NOTEBOOKS! Custom corporate notebooks.',
                'source' => 'MediaMafia'
            ),
            
            // ========== BUSINESS STATIONERY ==========
            'letterheads' => array(
                'name' => 'Letterheads',
                'category' => 'stationery',
                'price' => 1362.75,
                'original' => 908.50,
                'variations' => '500+ sheets, A4',
                'details' => 'Premium bond paper',
                'description' => '📄 PROFESSIONAL CORRESPONDENCE! Branded letterheads.',
                'source' => 'MediaMafia'
            ),
            'notepads' => array(
                'name' => 'Notepads',
                'category' => 'stationery',
                'price' => 37.50,
                'original' => 25.00,
                'variations' => 'Various sizes, 50-100 sheets',
                'details' => 'Glued pad with backing board',
                'description' => '📝 LEAVE YOUR MARK! Custom branded notepads.',
                'source' => 'ThePrintShop'
            ),
            'notepads_corporate' => array(
                'name' => 'Notepads (Corporate)',
                'category' => 'stationery',
                'price' => 246.90,
                'original' => 164.60,
                'variations' => 'A4/A5/DL sizes',
                'details' => 'Premium quality pads',
                'description' => '📋 EXECUTIVE NOTEPADS! Premium corporate stationery.',
                'source' => 'MediaMafia'
            ),
            'presentation_folders' => array(
                'name' => 'Presentation Folders',
                'category' => 'stationery',
                'price' => 37.50,
                'original' => 25.00,
                'variations' => 'A4 capacity, business card slot',
                'details' => 'Full colour print',
                'description' => '📁 IMPRESS AT MEETINGS! Professional folders.',
                'source' => 'ThePrintShop'
            ),
            'presentation_folders_corporate' => array(
                'name' => 'Presentation Folders (Corporate)',
                'category' => 'stationery',
                'price' => 345.00,
                'original' => 230.00,
                'variations' => 'Premium A4 with pockets',
                'details' => 'Die-cut pockets, business card slot',
                'description' => '💼 EXECUTIVE FOLDERS! Premium presentation folders.',
                'source' => 'MediaMafia'
            ),
            'branded_envelopes' => array(
                'name' => 'Envelopes (Branded)',
                'category' => 'stationery',
                'price' => 225.00,
                'original' => 150.00,
                'variations' => 'DL/C5/C4 sizes, 500 qty',
                'details' => 'Printed window or plain',
                'description' => '✉️ COMPLETE YOUR BRAND! Matching branded envelopes.',
                'source' => 'ThePrintShop'
            ),
            'swing_tags' => array(
                'name' => 'Swing Tags',
                'category' => 'stationery',
                'price' => 127.50,
                'original' => 85.00,
                'variations' => 'Various sizes and shapes',
                'details' => 'Die-cut with string/ribbon',
                'description' => '🏷️ TAG YOUR PRODUCTS! Custom swing tags.',
                'source' => 'ImpressOnline'
            ),
            
            // ========== PROMOTIONAL ITEMS ==========
            'mousepad' => array(
                'name' => 'Mousepad',
                'category' => 'promotional',
                'price' => 417.00,
                'original' => 278.00,
                'variations' => 'Standard 20x25cm',
                'details' => 'Full colour sublimation',
                'description' => '🖱️ DAILY BRAND EXPOSURE! Custom mousepads.',
                'source' => 'MediaMafia'
            ),
            'printed_cushion' => array(
                'name' => 'Printed Cushion',
                'category' => 'promotional',
                'price' => 600.00,
                'original' => 400.00,
                'variations' => 'Standard cushion size',
                'details' => 'Full colour print, polyester',
                'description' => '🛋️ COMFORT MEETS BRANDING! Custom cushions.',
                'source' => 'ThePrintShop'
            ),
            'car_sunshade' => array(
                'name' => 'Car Sunshade (Pair)',
                'category' => 'promotional',
                'price' => 525.00,
                'original' => 350.00,
                'variations' => 'Standard windscreen fit',
                'details' => 'Reflective, foldable',
                'description' => '☀️ PROTECT & PROMOTE! Branded car sunshades.',
                'source' => 'ThePrintShop'
            ),
            'laptop_skin' => array(
                'name' => 'Laptop Skin',
                'category' => 'promotional',
                'price' => 375.00,
                'original' => 250.00,
                'variations' => 'Custom sizes for all laptops',
                'details' => 'Removable vinyl',
                'description' => '💻 SKIN YOUR LAPTOP! Custom laptop skins.',
                'source' => 'ThePrintShop'
            ),
            'playing_cards' => array(
                'name' => 'Playing Cards',
                'category' => 'promotional',
                'price' => 517.50,
                'original' => 345.00,
                'variations' => 'Standard deck, custom design',
                'details' => 'Full colour, 52 cards + jokers',
                'description' => '🃏 DEAL YOUR BRAND! Custom playing cards.',
                'source' => 'MediaMafia'
            ),
            'clock' => array(
                'name' => 'Clock',
                'category' => 'promotional',
                'price' => 525.00,
                'original' => 350.00,
                'variations' => '25x25cm wall clock',
                'details' => 'Full face print, silent mechanism',
                'description' => '🕐 TIME FOR YOUR BRAND! Custom wall clocks.',
                'source' => 'ThePrintShop'
            ),
            'paper_coasters' => array(
                'name' => 'Paper Coasters',
                'category' => 'promotional',
                'price' => 3.36,
                'original' => 2.24,
                'variations' => 'Per coaster, min 80',
                'details' => 'Absorbent paper stock',
                'description' => '🍺 BAR PROMOTION! Custom paper coasters.',
                'source' => 'MediaMafia'
            ),
            'printed_placemats' => array(
                'name' => 'Printed Placemats',
                'category' => 'promotional',
                'price' => 10.53,
                'original' => 7.02,
                'variations' => 'Per placemat, min 25',
                'details' => 'Paper or laminated',
                'description' => '🍽️ DINE WITH YOUR BRAND! Restaurant placemats.',
                'source' => 'MediaMafia'
            ),
            'custom_fridge_magnets' => array(
                'name' => 'Custom Fridge Magnets',
                'category' => 'promotional',
                'price' => 200.28,
                'original' => 133.52,
                'variations' => 'Various sizes',
                'details' => 'Strong magnetic backing',
                'description' => '🧲 STICK AROUND! Custom fridge magnets.',
                'source' => 'MediaMafia'
            ),
            
            // ========== DIARIES ==========
            'branded_diaries' => array(
                'name' => 'Branded Diaries',
                'category' => 'diaries',
                'price' => 220.50,
                'original' => 147.00,
                'variations' => 'A5 size, week-to-view',
                'details' => 'Cover branded, quality pages',
                'description' => '📔 PLAN IN STYLE! Corporate branded diaries.',
                'source' => 'MediaMafia'
            ),
            'personalised_diaries' => array(
                'name' => 'Personalised Diaries',
                'category' => 'diaries',
                'price' => 87.97,
                'original' => 58.65,
                'variations' => 'Various styles and sizes',
                'details' => 'Name embossing available',
                'description' => '📖 MAKE IT PERSONAL! Personalised diaries.',
                'source' => 'MediaMafia'
            ),
            'custom_diaries' => array(
                'name' => 'Custom Diaries',
                'category' => 'diaries',
                'price' => 97.06,
                'original' => 64.71,
                'variations' => 'Full custom design',
                'details' => 'Complete custom interior',
                'description' => '✏️ YOUR DIARY, YOUR WAY! Fully custom diaries.',
                'source' => 'MediaMafia'
            ),
            
            // ========== POINT OF SALE ==========
            'table_talkers' => array(
                'name' => 'Table Talkers',
                'category' => 'pos',
                'price' => 600.00,
                'original' => 400.00,
                'variations' => 'A5/A6 sizes, 3-sided',
                'details' => 'Rigid, free-standing',
                'description' => '🍽️ TALK AT THE TABLE! Restaurant table talkers.',
                'source' => 'ThePrintShop'
            ),
            'custom_table_talkers' => array(
                'name' => 'Custom Table Talkers',
                'category' => 'pos',
                'price' => 258.75,
                'original' => 172.50,
                'variations' => 'Min 25, various sizes',
                'details' => 'Bulk quantity pricing',
                'description' => '💬 SPREAD THE WORD! Custom table displays.',
                'source' => 'MediaMafia'
            ),
            'strut_cards' => array(
                'name' => 'Strut Cards',
                'category' => 'pos',
                'price' => 97.50,
                'original' => 65.00,
                'variations' => 'A3 to A6 sizes',
                'details' => 'Self-standing with strut',
                'description' => '📢 POINT OF SALE POWER! Strut cards.',
                'source' => 'ImpressOnline'
            ),
            
            // ========== ACRYLIC PRODUCTS ==========
            'a4_brochure_holder' => array(
                'name' => 'A4 Brochure Holder',
                'category' => 'acrylic',
                'price' => 277.50,
                'original' => 185.00,
                'variations' => 'A4 landscape',
                'details' => 'Clear acrylic display',
                'description' => '📄 DISPLAY YOUR BROCHURES! Acrylic holders.',
                'source' => 'ImpressOnline'
            ),
            'business_card_holder' => array(
                'name' => 'Business Card Holder',
                'category' => 'acrylic',
                'price' => 142.50,
                'original' => 95.00,
                'variations' => 'Standard card size',
                'details' => 'Clear acrylic',
                'description' => '💳 DISPLAY YOUR CARDS! Acrylic card holders.',
                'source' => 'ImpressOnline'
            ),
            'dl_flyer_holder' => array(
                'name' => 'DL Flyer Holder',
                'category' => 'acrylic',
                'price' => 112.50,
                'original' => 75.00,
                'variations' => 'DL size rack',
                'details' => 'Wall mount or counter',
                'description' => '📄 RACK YOUR FLYERS! DL display holders.',
                'source' => 'ImpressOnline'
            ),
            
            // ========== PACKAGING ==========
            'branded_adhesive_tape' => array(
                'name' => 'Branded Adhesive Tape',
                'category' => 'packaging',
                'price' => 7417.50,
                'original' => 4945.00,
                'variations' => '5 boxes (36 rolls per box)',
                'details' => 'Custom printed packing tape',
                'description' => '📦 BRAND EVERY BOX! Custom packing tape.',
                'source' => 'MediaMafia'
            ),
            'mailer_boxes_economy' => array(
                'name' => 'Mailer Boxes (Economy)',
                'category' => 'packaging',
                'price' => 67.50,
                'original' => 45.00,
                'variations' => 'Various standard sizes',
                'details' => 'Brown kraft cardboard',
                'description' => '📦 SHIP IN STYLE! Economy mailer boxes.',
                'source' => 'ThePrintShop'
            ),
            'full_colour_mailer_boxes' => array(
                'name' => 'Full Colour Mailer Boxes',
                'category' => 'packaging',
                'price' => 127.50,
                'original' => 85.00,
                'variations' => 'Custom sizes available',
                'details' => 'Full colour print all over',
                'description' => '🎨 UNBOXING EXPERIENCE! Premium printed boxes.',
                'source' => 'ImpressOnline'
            ),
            'product_boxes_white' => array(
                'name' => 'Product Boxes (White)',
                'category' => 'packaging',
                'price' => 52.50,
                'original' => 35.00,
                'variations' => 'Various retail sizes',
                'details' => 'Clean white finish',
                'description' => '📦 RETAIL READY! White product boxes.',
                'source' => 'ThePrintShop'
            ),
            'custom_tissue_paper' => array(
                'name' => 'Custom Tissue Paper',
                'category' => 'packaging',
                'price' => 37.50,
                'original' => 25.00,
                'variations' => 'Single spot colour, per sheet',
                'details' => 'Lightweight tissue',
                'description' => '🎁 WRAP IN STYLE! Custom tissue paper.',
                'source' => 'ThePrintShop'
            ),
            'gift_wrapping_paper' => array(
                'name' => 'Gift Wrapping Paper',
                'category' => 'packaging',
                'price' => 67.50,
                'original' => 45.00,
                'variations' => 'Per roll, custom design',
                'details' => 'Full colour print',
                'description' => '🎁 WRAP YOUR BRAND! Custom wrapping paper.',
                'source' => 'ThePrintShop'
            ),
            
            // ========== LARGE FORMAT ==========
            'custom_wallpaper' => array(
                'name' => 'Wallpaper (Custom)',
                'category' => 'largeformat',
                'price' => 525.00,
                'original' => 350.00,
                'variations' => 'Per sqm, custom design',
                'details' => 'Removable or permanent',
                'description' => '🏠 TRANSFORM YOUR WALLS! Custom wallpaper.',
                'source' => 'ThePrintShop'
            ),
            'window_frosting' => array(
                'name' => 'Window Frosting',
                'category' => 'largeformat',
                'price' => 270.00,
                'original' => 180.00,
                'variations' => 'Per sqm, cut vinyl',
                'details' => 'Privacy frosting, custom cut',
                'description' => '🪟 PRIVACY & BRANDING! Window frosting.',
                'source' => 'ThePrintShop'
            ),
            'wall_decals' => array(
                'name' => 'Wall Decals',
                'category' => 'largeformat',
                'price' => 142.50,
                'original' => 95.00,
                'variations' => 'Custom sizes',
                'details' => 'Removable vinyl',
                'description' => '🎨 STICK TO YOUR WALLS! Custom wall decals.',
                'source' => 'ImpressOnline'
            ),
            'floor_graphics' => array(
                'name' => 'Floor Graphics',
                'category' => 'largeformat',
                'price' => 180.00,
                'original' => 120.00,
                'variations' => 'Anti-slip laminated',
                'details' => 'R10 anti-slip rated',
                'description' => '👣 WALK ON YOUR BRAND! Floor graphics.',
                'source' => 'ThePrintShop'
            ),
            
            // ========== VEHICLE BRANDING ==========
            'vehicle_decals_diy' => array(
                'name' => 'Vehicle Decals (DIY)',
                'category' => 'vehicle',
                'price' => 1650.00,
                'original' => 1100.00,
                'variations' => 'Set of branded decals',
                'details' => 'Self-application kit',
                'description' => '🚗 DIY VEHICLE BRANDING! Easy apply decals.',
                'source' => 'MediaMafia'
            ),
            'decal_drive_thru_service' => array(
                'name' => 'Decal Drive-Thru Service',
                'category' => 'vehicle',
                'price' => 2250.00,
                'original' => 1500.00,
                'variations' => 'Professional installation included',
                'details' => 'We apply for you',
                'description' => '🚙 DRIVE IN, DRIVE OUT BRANDED! Full service.',
                'source' => 'MediaMafia'
            ),
            'temporary_vehicle_decals' => array(
                'name' => 'Temporary Vehicle Decals',
                'category' => 'vehicle',
                'price' => 1121.25,
                'original' => 747.50,
                'variations' => 'Easy removal vinyl',
                'details' => 'No residue removal',
                'description' => '🚕 TEMPORARY BRANDING! Easy removal decals.',
                'source' => 'MediaMafia'
            ),
            
            // ========== EVENTS & DISPLAYS ==========
            'gazebos' => array(
                'name' => 'Gazebos',
                'category' => 'events',
                'price' => 5250.00,
                'original' => 3500.00,
                'variations' => '3x3m full branded gazebo',
                'details' => 'Full colour canopy, steel frame',
                'description' => '⛺ EVENT ESSENTIAL! Branded gazebos.',
                'source' => 'ThePrintShop'
            ),
            'branded_tablecloths' => array(
                'name' => 'Tablecloths (Branded)',
                'category' => 'events',
                'price' => 675.00,
                'original' => 450.00,
                'variations' => 'Fitted or throw style',
                'details' => 'Full colour sublimation',
                'description' => '🎪 DRESS YOUR TABLE! Branded tablecloths.',
                'source' => 'MediaMafia'
            ),
            'branded_parasols' => array(
                'name' => 'Parasols (Branded)',
                'category' => 'events',
                'price' => 1275.00,
                'original' => 850.00,
                'variations' => 'Large event parasol',
                'details' => 'UV resistant fabric',
                'description' => '☂️ SHADE & ADVERTISE! Branded parasols.',
                'source' => 'MediaMafia'
            ),
            'feather_teardrop_flags' => array(
                'name' => 'Flags (Feather/Teardrop)',
                'category' => 'events',
                'price' => 975.00,
                'original' => 650.00,
                'variations' => 'Various heights 2-4m',
                'details' => 'Double-sided print, pole included',
                'description' => '🚩 FLY YOUR BRAND! Feather & teardrop flags.',
                'source' => 'ThePrintShop'
            ),
            
            // ========== PHOTO SERVICES ==========
            'photo_printing' => array(
                'name' => 'Photo Printing',
                'category' => 'photos',
                'price' => 11.25,
                'original' => 7.50,
                'variations' => 'Per print, standard sizes',
                'details' => 'Gloss or matt finish',
                'description' => '📷 PRINT YOUR MEMORIES! Quality photo prints.',
                'source' => 'ThePrintShop'
            ),
            'id_passport_photos' => array(
                'name' => 'ID/Passport Photos',
                'category' => 'photos',
                'price' => 75.00,
                'original' => 50.00,
                'variations' => 'Set of 4 photos',
                'details' => 'Home Affairs compliant',
                'description' => '📸 OFFICIAL PHOTOS! ID & passport photos.',
                'source' => 'ThePrintShop'
            ),
            'photo_magnets' => array(
                'name' => 'Photo Magnets',
                'category' => 'photos',
                'price' => 67.50,
                'original' => 45.00,
                'variations' => 'Per magnet, various sizes',
                'details' => 'Strong magnetic backing',
                'description' => '🧲 STICK YOUR PHOTOS! Custom photo magnets.',
                'source' => 'ThePrintShop'
            ),
            
            // ========== SERVICES ==========
            'bulk_lamination' => array(
                'name' => 'Bulk Lamination',
                'category' => 'services',
                'price' => 525.00,
                'original' => 350.00,
                'variations' => 'Per 100 sheets A4',
                'details' => 'Gloss or matt',
                'description' => '🛡️ PROTECT YOUR PRINTS! Bulk lamination service.',
                'source' => 'ThePrintShop'
            ),
            'large_format_lamination' => array(
                'name' => 'Large Format Lamination',
                'category' => 'services',
                'price' => 52.50,
                'original' => 35.00,
                'variations' => 'Per sqm, up to A0+',
                'details' => 'Cold or hot lamination',
                'description' => '🛡️ PROTECT LARGE PRINTS! Large format lamination.',
                'source' => 'ThePrintShop'
            ),
            'plan_printing' => array(
                'name' => 'Plan Printing',
                'category' => 'services',
                'price' => 15.00,
                'original' => 10.00,
                'variations' => 'Per A1 print, B&W or colour',
                'details' => 'Architectural plans, engineering',
                'description' => '📐 PRINT YOUR PLANS! A1 plan printing.',
                'source' => 'ThePrintShop'
            ),
            'bulk_printing_binding' => array(
                'name' => 'Bulk Printing & Binding',
                'category' => 'services',
                'price' => 450.00,
                'original' => 300.00,
                'variations' => 'Per document, POA for large orders',
                'details' => 'Various binding options',
                'description' => '📚 BULK DOCUMENTS! Printing and binding service.',
                'source' => 'ThePrintShop'
            ),
            'document_printing' => array(
                'name' => 'Document Printing',
                'category' => 'services',
                'price' => 1.51,
                'original' => 1.01,
                'variations' => 'Per page, colour',
                'details' => 'High quality digital print',
                'description' => '📄 QUICK PRINTS! Document printing service.',
                'source' => 'ThePrintShop'
            ),
            
            // ========== SPECIAL ITEMS ==========
            'greeting_cards' => array(
                'name' => 'Greeting Cards',
                'category' => 'special',
                'price' => 75.00,
                'original' => 50.00,
                'variations' => 'A6/A5 sizes with envelopes',
                'details' => 'Full colour, scored fold',
                'description' => '💌 SEND YOUR MESSAGE! Custom greeting cards.',
                'source' => 'ThePrintShop'
            ),
            'large_novelty_cheque' => array(
                'name' => 'Large Novelty Cheque',
                'category' => 'special',
                'price' => 525.00,
                'original' => 350.00,
                'variations' => 'Giant presentation cheque',
                'details' => 'Foam board, full colour',
                'description' => '💰 BIG PRESENTATION! Giant novelty cheques.',
                'source' => 'ThePrintShop'
            ),
            'welcome_boards' => array(
                'name' => 'Welcome Boards',
                'category' => 'special',
                'price' => 115.50,
                'original' => 77.00,
                'variations' => 'A2/A1 sizes, various substrates',
                'details' => 'Perfect for weddings & events',
                'description' => '💒 WELCOME YOUR GUESTS! Event welcome boards.',
                'source' => 'MediaMafia'
            ),
            'house_number_signs' => array(
                'name' => 'House Number Signs',
                'category' => 'special',
                'price' => 603.75,
                'original' => 402.50,
                'variations' => 'Custom design, various materials',
                'details' => 'Acrylic, metal, or PVC',
                'description' => '🏠 NUMBER YOUR HOME! Custom house signs.',
                'source' => 'MediaMafia'
            ),
            'teacher_mug_set' => array(
                'name' => 'Teacher Mug Set',
                'category' => 'special',
                'price' => 158.70,
                'original' => 105.80,
                'variations' => 'Mug with gifts',
                'details' => 'Teacher appreciation gift set',
                'description' => '🍎 THANK A TEACHER! Gift mug set.',
                'source' => 'MediaMafia'
            ),
            'school_stationery_labels' => array(
                'name' => 'School Stationery Labels',
                'category' => 'special',
                'price' => 69.00,
                'original' => 46.00,
                'variations' => 'Set of name labels',
                'details' => 'Various sizes for books, lunchboxes',
                'description' => '🎒 LABEL EVERYTHING! School name labels.',
                'source' => 'MediaMafia'
            ),
        );
    }
    
    /**
     * Get categories
     */
    public static function get_categories() {
        return array(
            'business_cards' => array('name' => 'Business Cards', 'icon' => '💳', 'emoji' => '💳'),
            'flyers' => array('name' => 'Flyers & Leaflets', 'icon' => '📄', 'emoji' => '📄'),
            'posters' => array('name' => 'Posters', 'icon' => '🎨', 'emoji' => '🎨'),
            'banners' => array('name' => 'Banners', 'icon' => '🎪', 'emoji' => '🎪'),
            'signage' => array('name' => 'Signage', 'icon' => '🪧', 'emoji' => '🪧'),
            'mugs' => array('name' => 'Mugs & Drinkware', 'icon' => '☕', 'emoji' => '☕'),
            'calendars' => array('name' => 'Calendars', 'icon' => '📅', 'emoji' => '📅'),
            'stickers' => array('name' => 'Stickers & Labels', 'icon' => '🏷️', 'emoji' => '🏷️'),
            'stamps' => array('name' => 'Stamps', 'icon' => '📝', 'emoji' => '📝'),
            'canvas' => array('name' => 'Canvas & Art', 'icon' => '🖼️', 'emoji' => '🖼️'),
            'books' => array('name' => 'Books & Binding', 'icon' => '📚', 'emoji' => '📚'),
            'stationery' => array('name' => 'Business Stationery', 'icon' => '📋', 'emoji' => '📋'),
            'promotional' => array('name' => 'Promotional Items', 'icon' => '🎁', 'emoji' => '🎁'),
            'diaries' => array('name' => 'Diaries', 'icon' => '📔', 'emoji' => '📔'),
            'pos' => array('name' => 'Point of Sale', 'icon' => '🛒', 'emoji' => '🛒'),
            'acrylic' => array('name' => 'Acrylic Products', 'icon' => '💎', 'emoji' => '💎'),
            'packaging' => array('name' => 'Packaging', 'icon' => '📦', 'emoji' => '📦'),
            'largeformat' => array('name' => 'Large Format', 'icon' => '🖼️', 'emoji' => '🖼️'),
            'vehicle' => array('name' => 'Vehicle Branding', 'icon' => '🚗', 'emoji' => '🚗'),
            'events' => array('name' => 'Events & Displays', 'icon' => '🎪', 'emoji' => '🎪'),
            'photos' => array('name' => 'Photo Services', 'icon' => '📷', 'emoji' => '📷'),
            'services' => array('name' => 'Services', 'icon' => '⚙️', 'emoji' => '⚙️'),
            'special' => array('name' => 'Special Items', 'icon' => '✨', 'emoji' => '✨'),
        );
    }
    
    /**
     * Get single product
     */
    public static function get($key) {
        $products = self::get_all();
        return isset($products[$key]) ? $products[$key] : null;
    }
    
    /**
     * Get products by category
     */
    public static function get_by_category($category) {
        $products = self::get_all();
        return array_filter($products, function($p) use ($category) {
            return $p['category'] === $category;
        });
    }
    
    /**
     * Search products
     */
    public static function search($query) {
        $products = self::get_all();
        $query = strtolower($query);
        return array_filter($products, function($p) use ($query) {
            return strpos(strtolower($p['name']), $query) !== false ||
                   strpos(strtolower($p['description']), $query) !== false ||
                   strpos(strtolower($p['variations']), $query) !== false;
        });
    }
}
