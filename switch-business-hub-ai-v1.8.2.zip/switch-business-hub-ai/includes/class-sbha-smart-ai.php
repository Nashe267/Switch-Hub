<?php
/**
 * Smart AI Engine for Switch Graphics v1.8.2
 * 
 * More conversational, actually listens to user
 * Works with new product catalog format
 * 
 * @package SwitchBusinessHub
 * @version 1.8.2
 */

if (!defined('ABSPATH')) exit;

class SBHA_Smart_AI {
    
    private $context;
    private $products;
    private $categories;
    
    public function __construct() {
        require_once plugin_dir_path(__FILE__) . 'class-sbha-products.php';
        $this->products = SBHA_Products::get_all();
        $this->categories = SBHA_Products::get_categories();
    }
    
    /**
     * Process incoming message
     */
    public function process($message, $context = array()) {
        $this->context = wp_parse_args($context, array(
            'step' => 'greeting',
            'product_key' => '',
            'product_name' => '',
            'quantity' => 1,
            'needs_design' => null,
            'design_details' => '',
            'delivery_needed' => null,
            'delivery_location' => '',
            'special_notes' => '',
            'estimate_total' => 0,
            'messages' => array(),
            'items' => array()
        ));
        
        // Add user message to transcript
        $this->context['messages'][] = array(
            'role' => 'user',
            'content' => $message,
            'time' => current_time('mysql')
        );
        
        $msg = strtolower(trim($message));
        
        // Generate response based on message and context
        $response = $this->generate_response($msg, $message);
        
        // Add AI response to transcript
        $this->context['messages'][] = array(
            'role' => 'assistant',
            'content' => strip_tags($response['message']),
            'time' => current_time('mysql')
        );
        
        return array(
            'message' => $response['message'],
            'buttons' => $response['buttons'] ?? array(),
            'context' => $this->context,
            'show_quote_form' => $response['show_quote_form'] ?? false,
            'quote_data' => $response['quote_data'] ?? null
        );
    }
    
    /**
     * Generate response
     */
    private function generate_response($msg, $original) {
        // Check for tracking request
        if (preg_match('/(track|status|inv-|sbh|where.+order)/i', $msg)) {
            return $this->tracking_response();
        }
        
        // Check for greeting
        if (preg_match('/^(hi|hello|hey|howzit|morning|afternoon|evening)/i', $msg)) {
            return $this->greeting_response();
        }
        
        // Look for specific product match
        $product = $this->find_product($msg);
        if ($product) {
            return $this->show_product($product['key'], $product['data']);
        }
        
        // Handle conversation flow based on step
        switch ($this->context['step']) {
            case 'awaiting_quantity':
                return $this->handle_quantity($msg);
                
            case 'awaiting_design':
                return $this->handle_design($msg);
                
            case 'awaiting_design_details':
                return $this->handle_design_details($original);
                
            case 'awaiting_delivery':
                return $this->handle_delivery($msg);
                
            case 'awaiting_delivery_location':
                return $this->handle_location($original);
                
            case 'awaiting_more':
                return $this->handle_more($msg);
                
            case 'ready':
                return $this->finalize_quote();
        }
        
        // Check for category
        $category = $this->find_category($msg);
        if ($category) {
            return $this->show_category($category);
        }
        
        // Default - show what we offer
        return $this->greeting_response();
    }
    
    /**
     * Find matching product
     */
    private function find_product($msg) {
        $best_match = null;
        $best_score = 0;
        
        foreach ($this->products as $key => $product) {
            $name = strtolower($product['name']);
            $score = 0;
            
            // Exact name match
            if (strpos($msg, $name) !== false) {
                $score = 100;
            } else {
                // Check individual words
                $words = explode(' ', $name);
                foreach ($words as $word) {
                    if (strlen($word) > 2 && strpos($msg, $word) !== false) {
                        $score += 20;
                    }
                }
            }
            
            // Check variations
            $variations = strtolower($product['variations'] ?? '');
            if (strpos($msg, 'a5') !== false && strpos($variations, 'a5') !== false) $score += 15;
            if (strpos($msg, 'a4') !== false && strpos($variations, 'a4') !== false) $score += 15;
            if (strpos($msg, 'a3') !== false && strpos($variations, 'a3') !== false) $score += 15;
            if (strpos($msg, 'a6') !== false && strpos($variations, 'a6') !== false) $score += 15;
            if (strpos($msg, 'dl') !== false && strpos($variations, 'dl') !== false) $score += 15;
            
            if ($score > $best_score) {
                $best_score = $score;
                $best_match = array('key' => $key, 'data' => $product);
            }
        }
        
        return $best_score >= 20 ? $best_match : null;
    }
    
    /**
     * Find matching category
     */
    private function find_category($msg) {
        $cat_map = array(
            'business_cards' => array('business card', 'cards'),
            'flyers' => array('flyer', 'leaflet', 'pamphlet'),
            'posters' => array('poster'),
            'banners' => array('banner', 'pull up', 'pull-up', 'rollup', 'x-frame'),
            'signage' => array('sign', 'correx', 'corex', 'board'),
            'mugs' => array('mug', 'cup', 'drinkware'),
            'calendars' => array('calendar'),
            'stickers' => array('sticker', 'label'),
            'stamps' => array('stamp'),
            'canvas' => array('canvas', 'art'),
            'books' => array('book', 'binding', 'ncr', 'photobook'),
            'stationery' => array('letterhead', 'notepad', 'folder', 'envelope'),
            'promotional' => array('promo', 'mousepad', 'cushion', 'gift'),
            'diaries' => array('diary', 'planner'),
            'pos' => array('table talker', 'strut'),
            'acrylic' => array('acrylic', 'holder'),
            'packaging' => array('box', 'packaging', 'mailer'),
            'largeformat' => array('wallpaper', 'wall decal', 'window', 'floor'),
            'vehicle' => array('vehicle', 'car wrap', 'decal'),
            'events' => array('gazebo', 'tablecloth', 'flag', 'parasol'),
            'photos' => array('photo print', 'passport'),
            'services' => array('lamination', 'binding', 'plan print'),
            'special' => array('welcome board', 'wedding', 'greeting card'),
        );
        
        foreach ($cat_map as $cat => $keywords) {
            foreach ($keywords as $kw) {
                if (strpos($msg, $kw) !== false) {
                    return $cat;
                }
            }
        }
        
        return null;
    }
    
    /**
     * Greeting response
     */
    private function greeting_response() {
        $this->context['step'] = 'awaiting_product';
        
        return array(
            'message' => "Welcome to <strong>Switch Graphics</strong>! 👋\n\n" .
                "I can help you get a quick quote for any printing or branding needs.\n\n" .
                "<strong>What are you looking for?</strong>\n" .
                "Just type what you need (like 'business cards' or '500 flyers') or tap a button below:",
            'buttons' => array(
                array('text' => '💳 Business Cards', 'value' => 'business cards'),
                array('text' => '📄 Flyers', 'value' => 'flyers'),
                array('text' => '🎪 Banners', 'value' => 'banners'),
                array('text' => '🪧 Signs', 'value' => 'signage'),
                array('text' => '☕ Mugs', 'value' => 'mugs'),
            )
        );
    }
    
    /**
     * Show category products
     */
    private function show_category($category) {
        $cat_info = $this->categories[$category] ?? array('name' => ucfirst($category), 'emoji' => '📦');
        
        $cat_products = array_filter($this->products, function($p) use ($category) {
            return $p['category'] === $category;
        });
        
        if (empty($cat_products)) {
            return $this->greeting_response();
        }
        
        $msg = "{$cat_info['emoji']} <strong>{$cat_info['name']}</strong>\n\n";
        $buttons = array();
        
        foreach ($cat_products as $key => $product) {
            $msg .= "• <strong>{$product['name']}</strong> - R" . number_format($product['price'], 2) . "\n";
            $msg .= "  <em>{$this->truncate($product['description'], 50)}</em>\n\n";
            
            if (count($buttons) < 5) {
                $buttons[] = array(
                    'text' => $product['name'],
                    'value' => strtolower($product['name'])
                );
            }
        }
        
        $msg .= "Which one interests you?";
        
        $this->context['step'] = 'awaiting_product';
        
        return array(
            'message' => $msg,
            'buttons' => $buttons
        );
    }
    
    /**
     * Show product details
     */
    private function show_product($key, $product) {
        $this->context['product_key'] = $key;
        $this->context['product_name'] = $product['name'];
        $this->context['unit_price'] = $product['price'];
        $this->context['step'] = 'awaiting_quantity';
        
        $msg = "✅ <strong>{$product['name']}</strong>\n\n";
        $msg .= "{$product['description']}\n\n";
        $msg .= "💰 <strong>Price:</strong> R" . number_format($product['price'], 2) . "\n";
        $msg .= "📏 <strong>Options:</strong> {$product['variations']}\n\n";
        $msg .= "<strong>How many do you need?</strong>";
        
        return array(
            'message' => $msg,
            'buttons' => array(
                array('text' => '100', 'value' => '100'),
                array('text' => '250', 'value' => '250'),
                array('text' => '500', 'value' => '500'),
                array('text' => '1000', 'value' => '1000'),
            )
        );
    }
    
    /**
     * Handle quantity
     */
    private function handle_quantity($msg) {
        // Extract number
        preg_match('/(\d+)/', $msg, $matches);
        $qty = isset($matches[1]) ? intval($matches[1]) : 1;
        if ($qty < 1) $qty = 1;
        
        $this->context['quantity'] = $qty;
        $this->context['step'] = 'awaiting_design';
        
        $unit_price = $this->context['unit_price'] ?? 0;
        $subtotal = $unit_price * $qty;
        
        return array(
            'message' => "Got it! <strong>{$qty}x {$this->context['product_name']}</strong>\n\n" .
                "Subtotal: R" . number_format($subtotal, 2) . "\n\n" .
                "<strong>Do you need us to design this for you?</strong>\n" .
                "Or will you provide your own artwork?",
            'buttons' => array(
                array('text' => '🎨 Yes, design for me', 'value' => 'yes design'),
                array('text' => '📁 I have artwork', 'value' => 'have artwork'),
                array('text' => '🤷 Not sure yet', 'value' => 'not sure'),
            )
        );
    }
    
    /**
     * Handle design choice
     */
    private function handle_design($msg) {
        if (preg_match('/(yes|design|need|help|please)/i', $msg)) {
            $this->context['needs_design'] = true;
            $this->context['step'] = 'awaiting_design_details';
            
            return array(
                'message' => "No problem! 🎨 Our design team will help you.\n\n" .
                    "<strong>Please describe what you have in mind:</strong>\n" .
                    "• What should it say?\n" .
                    "• Any specific colours or style?\n" .
                    "• Do you have a logo?",
                'buttons' => array()
            );
        }
        
        // Has own artwork or not sure
        $this->context['needs_design'] = preg_match('/(not sure|maybe)/i', $msg);
        $this->context['step'] = 'awaiting_delivery';
        
        return array(
            'message' => "Perfect! You can send us your artwork when ready.\n\n" .
                "<strong>Would you like delivery or will you collect from our shop?</strong>\n\n" .
                "📍 <em>We're at 16 Harding Street, Newcastle</em>",
            'buttons' => array(
                array('text' => '🚚 Deliver to me', 'value' => 'delivery'),
                array('text' => '🏪 I will collect', 'value' => 'collect'),
            )
        );
    }
    
    /**
     * Handle design details
     */
    private function handle_design_details($msg) {
        $this->context['design_details'] = $msg;
        $this->context['step'] = 'awaiting_delivery';
        
        return array(
            'message' => "Thanks for the details! 📝 Our designers will work on this.\n\n" .
                "<strong>Delivery or collection?</strong>\n\n" .
                "📍 <em>Our shop is at 16 Harding Street, Newcastle</em>",
            'buttons' => array(
                array('text' => '🚚 Deliver to me', 'value' => 'delivery'),
                array('text' => '🏪 I will collect', 'value' => 'collect'),
            )
        );
    }
    
    /**
     * Handle delivery choice
     */
    private function handle_delivery($msg) {
        if (preg_match('/(deliver|ship|courier|send)/i', $msg)) {
            $this->context['delivery_needed'] = true;
            $this->context['step'] = 'awaiting_delivery_location';
            
            return array(
                'message' => "Sure! 🚚 Where should we deliver?\n\n" .
                    "Please provide your delivery address:",
                'buttons' => array()
            );
        }
        
        $this->context['delivery_needed'] = false;
        $this->context['step'] = 'awaiting_more';
        
        return $this->ask_more_items();
    }
    
    /**
     * Handle delivery location
     */
    private function handle_location($msg) {
        $this->context['delivery_location'] = $msg;
        $this->context['step'] = 'awaiting_more';
        
        return $this->ask_more_items();
    }
    
    /**
     * Ask about more items
     */
    private function ask_more_items() {
        // Add current item to items array
        $this->context['items'][] = array(
            'product_key' => $this->context['product_key'],
            'product_name' => $this->context['product_name'],
            'quantity' => $this->context['quantity'],
            'unit_price' => $this->context['unit_price'] ?? 0,
            'needs_design' => $this->context['needs_design'],
            'design_details' => $this->context['design_details']
        );
        
        return array(
            'message' => "Added to your quote! ✅\n\n" .
                "<strong>Would you like to add anything else?</strong>",
            'buttons' => array(
                array('text' => '➕ Add more products', 'value' => 'add more'),
                array('text' => '✅ No, get my quote', 'value' => 'done'),
            )
        );
    }
    
    /**
     * Handle more items choice
     */
    private function handle_more($msg) {
        if (preg_match('/(more|another|also|add|yes)/i', $msg)) {
            $this->context['step'] = 'awaiting_product';
            return $this->greeting_response();
        }
        
        return $this->finalize_quote();
    }
    
    /**
     * Finalize quote
     */
    private function finalize_quote() {
        $this->context['step'] = 'ready';
        
        // Calculate total
        $total = 0;
        $summary = "";
        
        foreach ($this->context['items'] as $item) {
            $subtotal = ($item['unit_price'] ?? 0) * ($item['quantity'] ?? 1);
            $total += $subtotal;
            $summary .= "• {$item['quantity']}x {$item['product_name']} - R" . number_format($subtotal, 2) . "\n";
            
            if (!empty($item['needs_design'])) {
                $total += 350;
                $summary .= "  + Design service - R350\n";
            }
        }
        
        if ($this->context['delivery_needed']) {
            $total += 150; // Estimate delivery
            $summary .= "• Estimated delivery - R150\n";
        }
        
        $this->context['estimate_total'] = $total;
        
        $msg = "🎉 <strong>Great! Here's your quote summary:</strong>\n\n";
        $msg .= $summary;
        $msg .= "\n💰 <strong>Estimated Total: R" . number_format($total, 2) . "</strong>\n\n";
        $msg .= "Please fill in your details below to submit your quote request. We'll WhatsApp you with the final quote!";
        
        return array(
            'message' => $msg,
            'buttons' => array(),
            'show_quote_form' => true,
            'quote_data' => array(
                'items' => $this->context['items'],
                'needs_design' => $this->context['needs_design'],
                'design_details' => $this->context['design_details'],
                'delivery_needed' => $this->context['delivery_needed'],
                'delivery_location' => $this->context['delivery_location'],
                'estimate_total' => $total
            )
        );
    }
    
    /**
     * Tracking response
     */
    private function tracking_response() {
        return array(
            'message' => "To track your order, please go to the <strong>Track</strong> tab and enter your invoice number.\n\n" .
                "Invoice numbers look like: <strong>INV-SBH001</strong>\n\n" .
                "You can also WhatsApp us for a quick update! 💬",
            'buttons' => array(
                array('text' => '💬 WhatsApp Us', 'value' => 'whatsapp'),
            )
        );
    }
    
    /**
     * Truncate text
     */
    private function truncate($text, $length) {
        if (strlen($text) <= $length) return $text;
        return substr($text, 0, $length) . '...';
    }
}
