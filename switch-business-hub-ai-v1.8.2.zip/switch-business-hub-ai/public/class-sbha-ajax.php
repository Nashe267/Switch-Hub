<?php
/**
 * AJAX Handler Class
 *
 * All frontend AJAX operations
 *
 * @package SwitchBusinessHub
 */

if (!defined('ABSPATH')) {
    exit;
}

class SBHA_Ajax {

    public function __construct() {
        // Customer auth (no WordPress users)
        add_action('wp_ajax_nopriv_sbha_register', array($this, 'register'));
        add_action('wp_ajax_sbha_register', array($this, 'register'));
        add_action('wp_ajax_nopriv_sbha_login', array($this, 'login'));
        add_action('wp_ajax_sbha_login', array($this, 'login'));
        add_action('wp_ajax_sbha_logout', array($this, 'logout'));
        add_action('wp_ajax_nopriv_sbha_logout', array($this, 'logout'));
        add_action('wp_ajax_nopriv_sbha_reset_password', array($this, 'reset_password'));

        // Quote submission (uses submit_ai_quote which handles account creation)
        add_action('wp_ajax_sbha_submit_quote', array($this, 'submit_ai_quote'));
        add_action('wp_ajax_nopriv_sbha_submit_quote', array($this, 'submit_ai_quote'));

        // Order tracking
        add_action('wp_ajax_sbha_track_order', array($this, 'track_order'));
        add_action('wp_ajax_nopriv_sbha_track_order', array($this, 'track_order'));

        // Customer orders
        add_action('wp_ajax_sbha_get_my_orders', array($this, 'get_my_orders'));
        add_action('wp_ajax_nopriv_sbha_get_my_orders', array($this, 'get_my_orders'));

        // Documents
        add_action('wp_ajax_sbha_get_documents', array($this, 'get_documents'));
        add_action('wp_ajax_nopriv_sbha_get_documents', array($this, 'get_documents'));

        // Contact
        add_action('wp_ajax_sbha_contact', array($this, 'contact'));
        add_action('wp_ajax_nopriv_sbha_contact', array($this, 'contact'));

        // Notifications
        add_action('wp_ajax_sbha_get_notifications', array($this, 'get_notifications'));
        add_action('wp_ajax_sbha_mark_read', array($this, 'mark_notification_read'));

        // Session check
        add_action('wp_ajax_sbha_check_session', array($this, 'check_session'));
        add_action('wp_ajax_nopriv_sbha_check_session', array($this, 'check_session'));

        // Services
        add_action('wp_ajax_sbha_get_services', array($this, 'get_services'));
        add_action('wp_ajax_nopriv_sbha_get_services', array($this, 'get_services'));

        // Admin: Approve/Decline quotes
        add_action('wp_ajax_sbha_approve_quote', array($this, 'approve_quote'));
        add_action('wp_ajax_sbha_decline_quote', array($this, 'decline_quote'));

        // AI Chat
        add_action('wp_ajax_sbha_ai_chat', array($this, 'ai_chat'));
        add_action('wp_ajax_nopriv_sbha_ai_chat', array($this, 'ai_chat'));
    }

    /**
     * Register customer - PHONE ONLY required
     */
    public function register() {
        global $wpdb;

        // Support both old and new parameter names
        $name = sanitize_text_field($_POST['name'] ?? '');
        $first_name = sanitize_text_field($_POST['first_name'] ?? '');
        $last_name = sanitize_text_field($_POST['last_name'] ?? '');
        
        // If name provided, split it
        if ($name && !$first_name) {
            $parts = explode(' ', $name, 2);
            $first_name = $parts[0];
            $last_name = $parts[1] ?? '';
        }
        
        $phone = sanitize_text_field($_POST['phone'] ?? $_POST['cell_number'] ?? '');
        $email = sanitize_email($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';

        // Phone is required, email is optional
        if (empty($first_name) || empty($phone) || empty($password)) {
            wp_send_json_error('Please enter name, WhatsApp number and password.');
        }

        if (strlen($password) < 4) {
            wp_send_json_error('Password must be at least 4 characters.');
        }

        // Normalize phone number
        $phone = preg_replace('/[^0-9]/', '', $phone);
        if (strlen($phone) < 10) {
            wp_send_json_error('Please enter a valid phone number.');
        }

        $table = $wpdb->prefix . 'sbha_customers';
        
        // Check if phone already exists
        $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM $table WHERE cell_number = %s OR whatsapp_number = %s", $phone, $phone));
        if ($exists) {
            wp_send_json_error('This phone number is already registered. Please login.');
        }

        $result = $wpdb->insert($table, array(
            'first_name' => $first_name,
            'last_name' => $last_name,
            'business_name' => '',
            'email' => $email,
            'cell_number' => $phone,
            'whatsapp_number' => $phone,
            'password' => password_hash($password, PASSWORD_DEFAULT),
            'status' => 'active'
        ));

        if (!$result) {
            wp_send_json_error('Registration failed. Please try again.');
        }

        $customer_id = $wpdb->insert_id;
        $token = $this->create_session($customer_id);

        setcookie('sbha_token', $token, time() + (30 * 24 * 60 * 60), COOKIEPATH, COOKIE_DOMAIN, is_ssl(), true);

        wp_send_json_success(array(
            'message' => 'Account created!',
            'customer' => array(
                'id' => $customer_id,
                'name' => $first_name . ' ' . $last_name,
                'phone' => $phone
            ),
            'token' => $token
        ));
    }

    /**
     * Login - by PHONE NUMBER
     */
    public function login() {
        global $wpdb;

        // Support both phone and email login
        $phone = sanitize_text_field($_POST['phone'] ?? '');
        $email = sanitize_email($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';

        if ((empty($phone) && empty($email)) || empty($password)) {
            wp_send_json_error('Enter phone/email and password.');
        }

        $table = $wpdb->prefix . 'sbha_customers';
        
        // Try phone first, then email
        if ($phone) {
            $phone = preg_replace('/[^0-9]/', '', $phone);
            $customer = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM $table WHERE (cell_number = %s OR whatsapp_number = %s) AND status = 'active'",
                $phone, $phone
            ), ARRAY_A);
        } else {
            $customer = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM $table WHERE email = %s AND status = 'active'",
                $email
            ), ARRAY_A);
        }

        if (!$customer || !password_verify($password, $customer['password'])) {
            wp_send_json_error('Invalid phone/email or password.');
        }

        $wpdb->update($table, array('last_login' => current_time('mysql')), array('id' => $customer['id']));

        $token = $this->create_session($customer['id']);
        setcookie('sbha_token', $token, time() + (30 * 24 * 60 * 60), COOKIEPATH, COOKIE_DOMAIN, is_ssl(), true);

        wp_send_json_success(array(
            'message' => 'Welcome back!',
            'customer' => array(
                'id' => $customer['id'],
                'name' => $customer['first_name'] . ' ' . $customer['last_name'],
                'email' => $customer['email']
            ),
            'token' => $token
        ));
    }

    /**
     * Logout
     */
    public function logout() {
        global $wpdb;
        $token = $_COOKIE['sbha_token'] ?? '';
        if ($token) {
            $wpdb->delete($wpdb->prefix . 'sbha_sessions', array('session_token' => $token));
        }
        setcookie('sbha_token', '', time() - 3600, COOKIEPATH, COOKIE_DOMAIN, is_ssl(), true);
        wp_send_json_success(array('message' => 'Logged out.'));
    }

    /**
     * Reset password (just email + new password)
     */
    public function reset_password() {
        global $wpdb;

        $email = sanitize_email($_POST['email'] ?? '');
        $new_password = $_POST['new_password'] ?? '';

        if (empty($email) || empty($new_password)) {
            wp_send_json_error('Enter email and new password.');
        }

        if (strlen($new_password) < 6) {
            wp_send_json_error('Password must be at least 6 characters.');
        }

        $table = $wpdb->prefix . 'sbha_customers';
        $customer = $wpdb->get_row($wpdb->prepare("SELECT id FROM $table WHERE email = %s", $email));

        if (!$customer) {
            wp_send_json_error('Email not found.');
        }

        $wpdb->update($table, array('password' => password_hash($new_password, PASSWORD_DEFAULT)), array('id' => $customer->id));

        wp_send_json_success(array('message' => 'Password updated! You can now login.'));
    }

    /**
     * Submit quote/order
     */
    public function submit_quote() {
        global $wpdb;

        $customer_id = $this->get_customer_id();

        // Create customer from form if not logged in
        if (!$customer_id) {
            $email = sanitize_email($_POST['customer_email'] ?? '');
            $name = sanitize_text_field($_POST['customer_name'] ?? '');
            $phone = sanitize_text_field($_POST['customer_phone'] ?? '');

            if (empty($email) || empty($name) || empty($phone)) {
                wp_send_json_error('Please fill in your details.');
            }

            $table = $wpdb->prefix . 'sbha_customers';
            $existing = $wpdb->get_row($wpdb->prepare("SELECT id FROM $table WHERE email = %s", $email));

            if ($existing) {
                $customer_id = $existing->id;
            } else {
                $parts = explode(' ', $name, 2);
                $wpdb->insert($table, array(
                    'first_name' => $parts[0],
                    'last_name' => $parts[1] ?? '',
                    'email' => $email,
                    'cell_number' => $phone,
                    'whatsapp_number' => $phone,
                    'password' => password_hash(wp_generate_password(12), PASSWORD_DEFAULT),
                    'status' => 'active'
                ));
                $customer_id = $wpdb->insert_id;
            }
        }

        $service_id = intval($_POST['service_type'] ?? 0);
        $custom_service = sanitize_text_field($_POST['custom_service'] ?? '');
        $description = sanitize_textarea_field($_POST['description'] ?? '');
        $quantity = max(1, intval($_POST['quantity'] ?? 1));
        $urgency = sanitize_text_field($_POST['urgency'] ?? 'standard');
        $title = sanitize_text_field($_POST['project_title'] ?? '');
        $client_budget = !empty($_POST['client_budget']) ? floatval($_POST['client_budget']) : null;
        $budget_notes = sanitize_textarea_field($_POST['budget_notes'] ?? '');

        if (!$service_id && empty($custom_service) && empty($title)) {
            wp_send_json_error('Please select a service or describe your request.');
        }

        $service_name = $custom_service ?: 'Custom Request';
        $unit_price = 0;

        if ($service_id) {
            $service = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}sbha_services WHERE id = %d", $service_id
            ));
            if ($service) {
                $unit_price = floatval($service->base_price);
                $service_name = $service->name;
            }
        }

        $mult = $urgency === 'express' ? 1.25 : ($urgency === 'rush' ? 1.5 : 1);
        $total = $unit_price * $quantity * $mult;

        // Generate invoice number (SBH-XXXXXX format)
        $count = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}sbha_orders") + 1;
        $order_number = 'SBH-' . str_pad($count, 6, '0', STR_PAD_LEFT);

        // Handle files
        $files = array();
        if (!empty($_FILES['files'])) {
            require_once(ABSPATH . 'wp-admin/includes/file.php');
            require_once(ABSPATH . 'wp-admin/includes/media.php');
            require_once(ABSPATH . 'wp-admin/includes/image.php');

            $uploaded = $_FILES['files'];
            $count = is_array($uploaded['name']) ? count($uploaded['name']) : 1;

            for ($i = 0; $i < $count; $i++) {
                $file = is_array($uploaded['name']) ? array(
                    'name' => $uploaded['name'][$i],
                    'type' => $uploaded['type'][$i],
                    'tmp_name' => $uploaded['tmp_name'][$i],
                    'error' => $uploaded['error'][$i],
                    'size' => $uploaded['size'][$i]
                ) : $uploaded;

                if ($file['error'] === UPLOAD_ERR_OK) {
                    $_FILES['upload'] = $file;
                    $att_id = media_handle_upload('upload', 0);
                    if (!is_wp_error($att_id)) {
                        $files[] = array('id' => $att_id, 'url' => wp_get_attachment_url($att_id), 'name' => $file['name']);
                    }
                }
            }
        }

        $wpdb->insert($wpdb->prefix . 'sbha_orders', array(
            'order_number' => $order_number,
            'customer_id' => $customer_id,
            'service_id' => $service_id ?: null,
            'custom_service' => $custom_service,
            'title' => $title ?: $service_name,
            'description' => $description,
            'quantity' => $quantity,
            'urgency' => $urgency,
            'unit_price' => $unit_price,
            'total' => $total,
            'client_budget' => $client_budget,
            'budget_notes' => $budget_notes,
            'files' => json_encode($files),
            'status' => 'pending',
            'quote_status' => 'pending'
        ));

        $order_id = $wpdb->insert_id;

        // Notify
        $this->notify($customer_id, 'order', 'Request Submitted', "Your request #{$order_number} is received!");

        // Email admin
        $customer = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}sbha_customers WHERE id = %d", $customer_id));
        $admin_email = get_option('sbha_business_email', get_option('admin_email'));

        $budget_info = $client_budget ? "\nClient Budget: R" . number_format($client_budget, 2) : '';
        $budget_info .= $budget_notes ? "\nBudget Notes: {$budget_notes}" : '';

        wp_mail($admin_email, "New Order: {$order_number}",
            "Order: {$order_number}\nCustomer: {$customer->first_name} {$customer->last_name}\n" .
            "Email: {$customer->email}\nPhone: {$customer->cell_number}\n" .
            "Service: {$service_name}\nOur Quote: R" . number_format($total, 2) . $budget_info .
            "\n\nPlease review and approve/decline in admin panel."
        );

        wp_send_json_success(array(
            'message' => 'Request submitted!',
            'order_number' => $order_number,
            'total' => 'R' . number_format($total, 2)
        ));
    }

    /**
     * Track order - INVOICE NUMBER ONLY
     */
    public function track_order() {
        global $wpdb;

        $invoice = sanitize_text_field($_POST['invoice'] ?? '');
        if (empty($invoice)) {
            wp_send_json_error('Please enter your invoice number (e.g. INV-SBH01).');
        }

        // Clean up invoice number - accept various formats
        $invoice = strtoupper(str_replace(' ', '', $invoice));
        
        // Handle various formats: INV-SBH01, INVSBH01, SBH01, 01, 1
        if (preg_match('/^(\d+)$/', $invoice, $matches)) {
            $invoice = 'INV-SBH' . str_pad($matches[1], 2, '0', STR_PAD_LEFT);
        } elseif (preg_match('/^SBH-?(\d+)$/i', $invoice, $matches)) {
            $invoice = 'INV-SBH' . str_pad($matches[1], 2, '0', STR_PAD_LEFT);
        } elseif (preg_match('/^INV-?SBH-?(\d+)$/i', $invoice, $matches)) {
            $invoice = 'INV-SBH' . str_pad($matches[1], 2, '0', STR_PAD_LEFT);
        }

        // Search in orders table
        $order = $wpdb->get_row($wpdb->prepare("
            SELECT o.*, c.first_name, c.last_name, s.name as service_name
            FROM {$wpdb->prefix}sbha_orders o
            LEFT JOIN {$wpdb->prefix}sbha_customers c ON o.customer_id = c.id
            LEFT JOIN {$wpdb->prefix}sbha_services s ON o.service_id = s.id
            WHERE o.order_number = %s OR o.order_number LIKE %s
            LIMIT 1
        ", $invoice, '%' . $invoice . '%'), ARRAY_A);

        // Also check jobs table
        if (!$order) {
            $job = $wpdb->get_row($wpdb->prepare("
                SELECT * FROM {$wpdb->prefix}sbha_jobs WHERE invoice_number = %s OR invoice_number LIKE %s LIMIT 1
            ", $invoice, '%' . $invoice . '%'), ARRAY_A);
            
            if ($job) {
                wp_send_json_success(array(
                    'invoice_number' => $job['invoice_number'],
                    'status' => $job['status'],
                    'date' => date('d M Y', strtotime($job['created_at'])),
                    'description' => $job['description'] ?? ''
                ));
            }
        }

        if (!$order) {
            wp_send_json_error('Order not found. Please check your invoice number.');
        }

        wp_send_json_success(array(
            'invoice_number' => $order['order_number'],
            'status' => $order['status'],
            'date' => date('d M Y', strtotime($order['created_at'])),
            'description' => $order['service_name'] ?: $order['custom_service'] ?: $order['title'],
            'total' => 'R' . number_format($order['total'], 2)
        ));
    }

    /**
     * Get customer's orders
     */
    public function get_my_orders() {
        global $wpdb;

        $customer_id = $this->get_customer_id();
        if (!$customer_id) {
            wp_send_json_success(array('orders' => array()));
        }

        $orders = $wpdb->get_results($wpdb->prepare("
            SELECT o.*, s.name as service_name
            FROM {$wpdb->prefix}sbha_orders o
            LEFT JOIN {$wpdb->prefix}sbha_services s ON o.service_id = s.id
            WHERE o.customer_id = %d ORDER BY o.created_at DESC LIMIT 20
        ", $customer_id), ARRAY_A);

        $result = array();
        $biz = get_option('sbha_business_name', 'Switch Hub');

        foreach ($orders as $o) {
            $result[] = array(
                'order_number' => $o['order_number'],
                'service_name' => $o['service_name'] ?: $o['custom_service'] ?: $o['title'],
                'status' => $o['status'],
                'status_label' => ucfirst(str_replace('_', ' ', $o['status'])),
                'total' => 'R' . number_format($o['total'], 2),
                'created_date' => date('d M Y', strtotime($o['created_at'])),
                'admin_response' => $o['admin_response'],
                'has_new_response' => $o['admin_response'] && !$o['customer_viewed_response'],
                'invoice_url' => $o['invoice_pdf_url'],
                'business_name' => $biz
            );
        }

        wp_send_json_success(array('orders' => $result));
    }

    /**
     * Get documents
     */
    public function get_documents() {
        global $wpdb;

        $email = sanitize_email($_POST['email'] ?? '');
        $customer_id = $this->get_customer_id();

        if (!$customer_id && $email) {
            $c = $wpdb->get_row($wpdb->prepare("SELECT id FROM {$wpdb->prefix}sbha_customers WHERE email = %s", $email));
            $customer_id = $c ? $c->id : null;
        }

        if (!$customer_id) {
            wp_send_json_success(array('documents' => array()));
        }

        $quotes = $wpdb->get_results($wpdb->prepare("
            SELECT q.*, o.title as service FROM {$wpdb->prefix}sbha_quotes q
            JOIN {$wpdb->prefix}sbha_orders o ON q.order_id = o.id
            WHERE q.customer_id = %d ORDER BY q.created_at DESC
        ", $customer_id), ARRAY_A);

        $invoices = $wpdb->get_results($wpdb->prepare("
            SELECT i.*, o.title as service FROM {$wpdb->prefix}sbha_invoices i
            JOIN {$wpdb->prefix}sbha_orders o ON i.order_id = o.id
            WHERE i.customer_id = %d ORDER BY i.created_at DESC
        ", $customer_id), ARRAY_A);

        $docs = array();
        foreach ($quotes as $q) {
            $docs[] = array('type' => 'Quote', 'number' => $q['quote_number'], 'service' => $q['service'],
                'total' => 'R' . number_format($q['total'], 2), 'date' => date('d M Y', strtotime($q['created_at'])),
                'status' => $q['status'], 'pdf_url' => $q['pdf_url']);
        }
        foreach ($invoices as $i) {
            $docs[] = array('type' => 'Invoice', 'number' => $i['invoice_number'], 'service' => $i['service'],
                'total' => 'R' . number_format($i['total'], 2), 'date' => date('d M Y', strtotime($i['created_at'])),
                'status' => $i['status'], 'pdf_url' => $i['pdf_url']);
        }

        wp_send_json_success(array('documents' => $docs));
    }

    /**
     * Contact
     */
    public function contact() {
        global $wpdb;

        $name = sanitize_text_field($_POST['name'] ?? '');
        $email = sanitize_email($_POST['email'] ?? '');
        $phone = sanitize_text_field($_POST['phone'] ?? '');
        $message = sanitize_textarea_field($_POST['message'] ?? '');

        if (empty($name) || empty($email) || empty($message)) {
            wp_send_json_error('Fill in all required fields.');
        }

        $wpdb->insert($wpdb->prefix . 'sbha_messages', array(
            'customer_id' => $this->get_customer_id(),
            'name' => $name, 'email' => $email, 'phone' => $phone, 'message' => $message
        ));

        wp_mail(get_option('sbha_business_email', get_option('admin_email')),
            "Message from {$name}", "Name: {$name}\nEmail: {$email}\nPhone: {$phone}\n\n{$message}",
            array("Reply-To: {$email}"));

        wp_send_json_success(array('message' => 'Message sent!'));
    }

    /**
     * Get notifications
     */
    public function get_notifications() {
        global $wpdb;
        $customer_id = $this->get_customer_id();
        if (!$customer_id) wp_send_json_success(array('notifications' => array(), 'unread' => 0));

        $notifs = $wpdb->get_results($wpdb->prepare("
            SELECT * FROM {$wpdb->prefix}sbha_notifications
            WHERE customer_id = %d ORDER BY created_at DESC LIMIT 20
        ", $customer_id), ARRAY_A);

        $unread = $wpdb->get_var($wpdb->prepare("
            SELECT COUNT(*) FROM {$wpdb->prefix}sbha_notifications WHERE customer_id = %d AND is_read = 0
        ", $customer_id));

        wp_send_json_success(array('notifications' => $notifs, 'unread' => intval($unread)));
    }

    /**
     * Mark notification read
     */
    public function mark_notification_read() {
        global $wpdb;
        $id = intval($_POST['id'] ?? 0);
        $customer_id = $this->get_customer_id();
        if ($id && $customer_id) {
            $wpdb->update($wpdb->prefix . 'sbha_notifications', array('is_read' => 1),
                array('id' => $id, 'customer_id' => $customer_id));
        }
        wp_send_json_success();
    }

    /**
     * Check session
     */
    public function check_session() {
        $customer = $this->get_customer();
        if ($customer) {
            wp_send_json_success(array('logged_in' => true, 'customer' => array(
                'id' => $customer['id'],
                'name' => $customer['first_name'] . ' ' . $customer['last_name'],
                'email' => $customer['email']
            )));
        }
        wp_send_json_success(array('logged_in' => false));
    }

    /**
     * Get services
     */
    public function get_services() {
        global $wpdb;
        $category = sanitize_text_field($_POST['category'] ?? 'all');

        $where = "status = 'active'";
        if ($category !== 'all') {
            $where .= $wpdb->prepare(" AND category = %s", $category);
        }

        $services = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}sbha_services WHERE {$where} ORDER BY display_order ASC");
        wp_send_json_success(array('services' => $services));
    }

    // Helpers
    private function create_session($customer_id) {
        global $wpdb;
        $token = bin2hex(random_bytes(32));
        $wpdb->insert($wpdb->prefix . 'sbha_sessions', array(
            'customer_id' => $customer_id,
            'session_token' => $token,
            'ip_address' => $_SERVER['REMOTE_ADDR'] ?? '',
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
            'expires_at' => date('Y-m-d H:i:s', time() + 2592000)
        ));
        return $token;
    }

    private function get_customer_id() {
        $c = $this->get_customer();
        return $c ? $c['id'] : null;
    }

    private function get_customer() {
        global $wpdb;
        $token = $_COOKIE['sbha_token'] ?? ($_POST['token'] ?? '');
        if (!$token) return null;

        $sess = $wpdb->get_row($wpdb->prepare("
            SELECT * FROM {$wpdb->prefix}sbha_sessions WHERE session_token = %s AND expires_at > NOW()
        ", $token), ARRAY_A);
        if (!$sess) return null;

        return $wpdb->get_row($wpdb->prepare("
            SELECT * FROM {$wpdb->prefix}sbha_customers WHERE id = %d AND status = 'active'
        ", $sess['customer_id']), ARRAY_A);
    }

    private function notify($customer_id, $type, $title, $message, $link = '') {
        global $wpdb;
        $wpdb->insert($wpdb->prefix . 'sbha_notifications', array(
            'customer_id' => $customer_id, 'type' => $type, 'title' => $title, 'message' => $message, 'link' => $link
        ));
    }

    /**
     * Approve quote (Admin only)
     */
    public function approve_quote() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }

        global $wpdb;
        $order_id = intval($_POST['order_id'] ?? 0);
        $note = sanitize_textarea_field($_POST['note'] ?? '');

        if (!$order_id) {
            wp_send_json_error('Invalid order.');
        }

        $order = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}sbha_orders WHERE id = %d", $order_id), ARRAY_A);
        if (!$order) {
            wp_send_json_error('Order not found.');
        }

        $wpdb->update($wpdb->prefix . 'sbha_orders', array(
            'quote_status' => 'approved',
            'quote_response_note' => $note,
            'quote_responded_at' => current_time('mysql'),
            'status' => 'confirmed'
        ), array('id' => $order_id));

        // Notify customer
        $this->notify(
            $order['customer_id'],
            'quote_approved',
            'Quote Approved!',
            "Great news! Your quote #{$order['order_number']} has been approved." . ($note ? " Note: {$note}" : '')
        );

        // Email customer
        $customer = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}sbha_customers WHERE id = %d", $order['customer_id']));
        if ($customer) {
            $biz = get_option('sbha_business_name', 'Switch Hub');
            wp_mail($customer->email, "Quote Approved - {$order['order_number']}",
                "Hi {$customer->first_name},\n\nGreat news! Your quote #{$order['order_number']} has been APPROVED.\n\n" .
                ($note ? "Note from {$biz}: {$note}\n\n" : "") .
                "We will begin working on your order shortly.\n\nThank you!\n{$biz}"
            );
        }

        wp_send_json_success(array('message' => 'Quote approved!'));
    }

    /**
     * Decline quote (Admin only)
     */
    public function decline_quote() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }

        global $wpdb;
        $order_id = intval($_POST['order_id'] ?? 0);
        $note = sanitize_textarea_field($_POST['note'] ?? '');

        if (!$order_id) {
            wp_send_json_error('Invalid order.');
        }

        $order = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}sbha_orders WHERE id = %d", $order_id), ARRAY_A);
        if (!$order) {
            wp_send_json_error('Order not found.');
        }

        $wpdb->update($wpdb->prefix . 'sbha_orders', array(
            'quote_status' => 'declined',
            'quote_response_note' => $note,
            'quote_responded_at' => current_time('mysql'),
            'status' => 'cancelled'
        ), array('id' => $order_id));

        // Notify customer
        $this->notify(
            $order['customer_id'],
            'quote_declined',
            'Quote Update',
            "Your quote #{$order['order_number']} could not be approved at this time." . ($note ? " Note: {$note}" : '')
        );

        // Email customer
        $customer = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}sbha_customers WHERE id = %d", $order['customer_id']));
        if ($customer) {
            $biz = get_option('sbha_business_name', 'Switch Hub');
            wp_mail($customer->email, "Quote Update - {$order['order_number']}",
                "Hi {$customer->first_name},\n\nWe've reviewed your quote #{$order['order_number']}.\n\n" .
                "Unfortunately, we're unable to proceed with this request at this time.\n\n" .
                ($note ? "Note: {$note}\n\n" : "") .
                "Please feel free to submit a new request or contact us to discuss alternatives.\n\nThank you!\n{$biz}"
            );
        }

        wp_send_json_success(array('message' => 'Quote declined.'));
    }

    /**
     * AI Chat - Smart Print & Graphics Industry Assistant
     */
    public function ai_chat() {
        $message = sanitize_text_field($_POST['message'] ?? '');
        $context_json = stripslashes($_POST['context'] ?? '{}');
        
        if (empty($message)) {
            wp_send_json_error('Please enter a message.');
        }

        // Parse context
        $context = json_decode($context_json, true);
        if (!is_array($context)) {
            $context = array();
        }
        
        // Load Smart AI
        require_once SBHA_PLUGIN_DIR . 'includes/class-sbha-smart-ai.php';
        $ai = new SBHA_Smart_AI();
        
        // Process message
        $result = $ai->process($message, $context);
        
        wp_send_json_success(array(
            'message' => $result['message'],
            'buttons' => $result['buttons'] ?? array(),
            'context' => $result['context'] ?? array(),
            'show_quote_form' => $result['show_quote_form'] ?? false,
            'quote_data' => $result['quote_data'] ?? null
        ));
    }

    /**
     * Submit quote from AI conversation
     * Creates account if needed and logs user in
     */
    public function submit_ai_quote() {
        global $wpdb;

        check_ajax_referer('sbha_nonce', 'nonce');

        $name = sanitize_text_field($_POST['name'] ?? '');
        $email = sanitize_email($_POST['email'] ?? '');
        $phone = sanitize_text_field($_POST['phone'] ?? '');
        $password = $_POST['password'] ?? '';
        $quote_data = json_decode(stripslashes($_POST['quote_data'] ?? '{}'), true);
        $transcript_raw = $_POST['transcript'] ?? '';
        $transcript = is_string($transcript_raw) ? $transcript_raw : json_encode($transcript_raw);

        // Phone is required
        if (empty($name) || empty($phone)) {
            wp_send_json_error('Please enter your name and WhatsApp number.');
        }

        // Normalize phone
        $phone = preg_replace('/[^0-9]/', '', $phone);

        // Generate quote number
        $count = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}sbha_quotes") + 1;
        $quote_number = 'QT-SBH' . str_pad($count, 4, '0', STR_PAD_LEFT);

        // Check if customer exists
        $table = $wpdb->prefix . 'sbha_customers';
        $existing = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table WHERE cell_number = %s OR whatsapp_number = %s",
            $phone, $phone
        ));
        
        $account_created = false;
        
        if ($existing) {
            $customer_id = $existing->id;
        } else {
            // Create new customer
            $parts = explode(' ', $name, 2);
            $new_password = $password ?: wp_generate_password(8);
            
            $wpdb->insert($table, array(
                'first_name' => $parts[0],
                'last_name' => $parts[1] ?? '',
                'email' => $email,
                'cell_number' => $phone,
                'whatsapp_number' => $phone,
                'business_name' => '',
                'password' => password_hash($new_password, PASSWORD_DEFAULT),
                'status' => 'active'
            ));
            $customer_id = $wpdb->insert_id;
            $account_created = true;
            
            // Log them in
            $token = $this->create_session($customer_id);
            setcookie('sbha_token', $token, time() + (30 * 24 * 60 * 60), COOKIEPATH, COOKIE_DOMAIN, is_ssl(), true);
        }

        // Build items summary from quote_data or context
        $items_summary = array();
        $total = 0;
        
        // Try to get items from quote_data
        $items_array = $quote_data['items'] ?? $quote_data['items'] ?? array();
        
        if (!empty($items_array)) {
            foreach ($items_array as $item) {
                $unit_price = $item['unit_price'] ?? $item['price'] ?? 0;
                $qty = $item['quantity'] ?? 1;
                $item_total = $unit_price * $qty;
                $total += $item_total;
                
                $items_summary[] = array(
                    'product' => $item['product_name'] ?? $item['product'] ?? '',
                    'variant' => $item['variant_name'] ?? '',
                    'sku' => $item['variant_sku'] ?? $item['sku'] ?? '',
                    'size' => $item['size'] ?? '',
                    'quantity' => $qty,
                    'unit_price' => $unit_price,
                    'subtotal' => $item_total,
                    'needs_design' => $item['needs_design'] ?? false,
                    'design_details' => $item['design_details'] ?? ''
                );
            }
        }

        // Use estimate total if provided
        if (!empty($quote_data['estimate_total'])) {
            $total = $quote_data['estimate_total'];
        }

        // If we have product info but no items, create one
        if (empty($items_summary) && !empty($quote_data['product_name'])) {
            $items_summary[] = array(
                'product' => $quote_data['product_name'],
                'quantity' => $quote_data['quantity'] ?? 1,
                'unit_price' => $quote_data['unit_price'] ?? 0,
                'needs_design' => $quote_data['needs_design'] ?? false
            );
            $total = ($quote_data['unit_price'] ?? 0) * ($quote_data['quantity'] ?? 1);
        }

        // Insert quote
        $wpdb->insert($wpdb->prefix . 'sbha_quotes', array(
            'quote_number' => $quote_number,
            'customer_id' => $customer_id,
            'email' => $email,
            'phone' => $phone,
            'company' => '',
            'items' => json_encode($items_summary),
            'item_count' => count($items_summary),
            'needs_design' => !empty($quote_data['needs_design']) ? 1 : 0,
            'design_details' => $quote_data['design_details'] ?? '',
            'event_type' => $quote_data['event_type'] ?? '',
            'event_date' => $quote_data['event_date'] ?? '',
            'delivery_needed' => !empty($quote_data['delivery_needed']) ? 1 : 0,
            'delivery_location' => $quote_data['delivery_location'] ?? '',
            'special_notes' => $quote_data['special_notes'] ?? '',
            'chat_transcript' => $transcript,
            'total' => $total,
            'status' => 'pending',
            'created_at' => current_time('mysql')
        ));

        $quote_id = $wpdb->insert_id;

        // Email admin
        $admin_email = get_option('sbha_business_email', get_option('admin_email'));
        
        $email_body = "New Quote Request: {$quote_number}\n\n";
        $email_body .= "Customer: {$name}\n";
        $email_body .= "Email: {$email}\n";
        $email_body .= "Phone: {$phone}\n";
        if ($company) $email_body .= "Company: {$company}\n";
        $email_body .= "\n--- ITEMS ---\n";
        
        foreach ($items_summary as $item) {
            $email_body .= "\n{$item['product']} - {$item['variant']}\n";
            $email_body .= "  SKU: {$item['sku']}\n";
            $email_body .= "  Qty: {$item['quantity']} @ R{$item['unit_price']} = R{$item['subtotal']}\n";
            if ($item['needs_design']) {
                $email_body .= "  NEEDS DESIGN (+R350)\n";
            }
        }
        
        $email_body .= "\n--- DETAILS ---\n";
        if (!empty($quote_data['event_type'])) $email_body .= "Event: {$quote_data['event_type']}\n";
        if (!empty($quote_data['event_date'])) $email_body .= "Needed by: {$quote_data['event_date']}\n";
        if (!empty($quote_data['delivery_location'])) $email_body .= "Delivery: {$quote_data['delivery_location']}\n";
        if (!empty($quote_data['special_notes'])) $email_body .= "Notes: {$quote_data['special_notes']}\n";
        
        $email_body .= "\n💰 ESTIMATED TOTAL: R" . number_format($total, 2) . "\n";
        $email_body .= "\n--- CHAT TRANSCRIPT ---\n" . $transcript;

        wp_mail($admin_email, "New Quote: {$quote_number} - {$name}", $email_body);

        // Email customer
        $customer_email = "Hi {$name},\n\n";
        $customer_email .= "Thank you for your quote request!\n\n";
        $customer_email .= "Quote Reference: {$quote_number}\n";
        $customer_email .= "Estimated Total: R" . number_format($total, 2) . "\n\n";
        $customer_email .= "We'll review your request and send you a formal quote shortly.\n\n";
        $customer_email .= "If you have any questions, feel free to WhatsApp us at " . get_option('sbha_whatsapp', '068 147 4232') . "\n\n";
        $customer_email .= "Thank you for choosing Switch Graphics!\n\n";
        $customer_email .= "---\n";
        $customer_email .= "Switch Graphics (Pty) Ltd\n";
        $customer_email .= "16 Harding Street, Newcastle, 2940\n";
        $customer_email .= "Tel: 068 147 4232\n";
        $customer_email .= "www.switchgraphics.co.za";

        if ($email) {
            wp_mail($email, "Quote Request Received - {$quote_number}", $customer_email);
        }

        wp_send_json_success(array(
            'message' => 'Quote submitted successfully!',
            'quote_number' => $quote_number,
            'quote_id' => $quote_id,
            'account_created' => $account_created
        ));
    }
}

new SBHA_Ajax();
