<?php
/**
 * Switch Graphics Customer Portal v1.8.2
 * 
 * FIXES:
 * 1. Products as a proper SHOP
 * 2. AI works for EVERYONE (logged in or not)
 * 3. Registration needs ONLY phone number (WhatsApp)
 * 4. Header text in ORANGE
 * 5. Banking details BRIGHT colors
 * 6. Quote submission creates account
 * 7. Saved chats visible to admin
 * 
 * @package SwitchBusinessHub
 * @version 1.8.2
 */

if (!defined('ABSPATH')) exit;

class SBHA_Shortcodes {

    public function __construct() {
        add_shortcode('switch_hub', array($this, 'render'));
    }

    public function render($atts) {
        global $wpdb;

        $atts = shortcode_atts(array(
            'primary' => get_option('sbha_primary_color', '#FF6600'),
        ), $atts);

        $ajax_url = admin_url('admin-ajax.php');
        $nonce = wp_create_nonce('sbha_nonce');

        // Check custom session
        $customer = $this->get_logged_in_customer();
        $is_logged_in = !empty($customer);

        // Load products
        require_once plugin_dir_path(dirname(__FILE__)) . 'includes/class-sbha-products.php';
        $products = SBHA_Products::get_all();
        $categories = SBHA_Products::get_categories();

        // Get customer stats if logged in
        $stats = array('quotes' => 0, 'orders' => 0);
        if ($is_logged_in) {
            $stats['quotes'] = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->prefix}sbha_quotes WHERE customer_id = %d",
                $customer['id']
            )) ?: 0;
        }

        ob_start();
        ?>
        <style>
        /* ========== VARIABLES ========== */
        .sgp{--primary:#FF6600;--primary-light:#ff8533;--primary-dark:#e55a00;--dark:#1a1a2e;--bg:#f8f9fa;--card:#fff;--text:#1f2937;--text-light:#6b7280;--border:#e5e7eb;--success:#22c55e;--warning:#f59e0b;--error:#ef4444;--radius:16px;--shadow:0 2px 8px rgba(0,0,0,0.08);font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;background:var(--bg);min-height:100vh;color:var(--text);line-height:1.6;padding-bottom:80px}
        .sgp *{box-sizing:border-box;margin:0;padding:0}

        /* ========== HEADER - ORANGE TEXT ========== */
        .sgp-header{background:linear-gradient(135deg,var(--dark),#0f172a);padding:24px 16px;text-align:center}
        .sgp-header h1{font-size:22px;font-weight:700;color:var(--primary);margin-bottom:4px}
        .sgp-header p{font-size:12px;color:rgba(255,255,255,0.7)}
        .sgp-header-btns{display:flex;justify-content:center;gap:10px;margin-top:16px}
        .sgp-btn{display:inline-flex;align-items:center;justify-content:center;gap:6px;padding:12px 24px;border:none;border-radius:30px;font-size:14px;font-weight:600;cursor:pointer;transition:all 0.2s;text-decoration:none}
        .sgp-btn-primary{background:var(--primary);color:#fff}
        .sgp-btn-primary:hover{background:var(--primary-light);transform:translateY(-2px)}
        .sgp-btn-outline{background:transparent;border:2px solid rgba(255,255,255,0.3);color:#fff}
        .sgp-btn-outline:hover{background:rgba(255,255,255,0.1);border-color:#fff}
        .sgp-user-pill{display:flex;align-items:center;gap:10px;background:rgba(255,102,0,0.2);padding:8px 16px;border-radius:30px;color:#fff}
        .sgp-user-avatar{width:32px;height:32px;background:var(--primary);border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:14px}

        /* ========== AI CHAT - WORKS FOR ALL ========== */
        .sgp-ai{background:linear-gradient(135deg,var(--primary),var(--primary-light));padding:20px 16px;border-radius:0 0 24px 24px}
        .sgp-ai-header{display:flex;align-items:center;gap:12px;margin-bottom:16px;color:#fff}
        .sgp-ai-icon{width:50px;height:50px;background:#fff;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:26px}
        .sgp-ai-header h2{font-size:18px;font-weight:700}
        .sgp-ai-header p{font-size:13px;opacity:0.9}
        .sgp-chat{background:rgba(255,255,255,0.15);backdrop-filter:blur(10px);border-radius:var(--radius);padding:14px;max-height:350px;overflow-y:auto;margin-bottom:12px}
        .sgp-msg{margin-bottom:10px;animation:fadeIn 0.3s}
        @keyframes fadeIn{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}
        .sgp-msg-ai{background:#fff;color:var(--text);padding:12px 16px;border-radius:16px 16px 16px 4px;font-size:14px;line-height:1.6;box-shadow:var(--shadow)}
        .sgp-msg-user{background:var(--dark);color:#fff;padding:10px 16px;border-radius:16px 16px 4px 16px;margin-left:40px;font-size:13px}
        .sgp-quick{display:flex;flex-wrap:wrap;gap:8px;margin-top:12px}
        .sgp-quick-btn{background:#fff;color:var(--primary);border:none;padding:10px 16px;border-radius:20px;font-size:12px;font-weight:600;cursor:pointer;transition:all 0.2s;box-shadow:var(--shadow)}
        .sgp-quick-btn:hover{background:var(--dark);color:#fff;transform:translateY(-2px)}
        .sgp-input-row{display:flex;gap:8px}
        .sgp-input-row input{flex:1;padding:14px 18px;border:none;border-radius:30px;font-size:14px;background:#fff}
        .sgp-input-row input:focus{outline:none;box-shadow:0 0 0 3px rgba(255,102,0,0.3)}
        .sgp-input-row button{width:50px;height:50px;border-radius:50%;background:#fff;border:none;font-size:20px;cursor:pointer;transition:all 0.2s}
        .sgp-input-row button:hover{background:var(--dark);color:#fff}

        /* ========== NAVIGATION ========== */
        .sgp-nav{position:fixed;bottom:0;left:0;right:0;background:#fff;display:flex;justify-content:space-around;padding:8px 0;border-top:1px solid var(--border);z-index:100;box-shadow:0 -2px 10px rgba(0,0,0,0.05)}
        .sgp-nav-btn{display:flex;flex-direction:column;align-items:center;gap:2px;background:none;border:none;color:var(--text-light);font-size:10px;font-weight:500;cursor:pointer;padding:8px 12px;border-radius:12px;transition:all 0.2s}
        .sgp-nav-btn svg{width:22px;height:22px}
        .sgp-nav-btn.active{color:var(--primary);background:rgba(255,102,0,0.1)}
        .sgp-panel{display:none;padding:20px 16px;max-width:600px;margin:0 auto}
        .sgp-panel.active{display:block}

        /* ========== SHOP - PRODUCT GRID ========== */
        .sgp-shop-header{display:flex;align-items:center;gap:10px;margin-bottom:16px}
        .sgp-shop-header h2{font-size:20px;font-weight:700}
        .sgp-filters{display:flex;overflow-x:auto;gap:8px;padding-bottom:12px;margin-bottom:16px;-webkit-overflow-scrolling:touch}
        .sgp-filters::-webkit-scrollbar{display:none}
        .sgp-filter{flex-shrink:0;padding:10px 16px;border:2px solid var(--border);background:#fff;border-radius:25px;font-size:12px;font-weight:500;cursor:pointer;transition:all 0.2s;white-space:nowrap}
        .sgp-filter.active,.sgp-filter:hover{border-color:var(--primary);background:var(--primary);color:#fff}
        .sgp-products{display:grid;grid-template-columns:repeat(2,1fr);gap:12px}
        @media(max-width:400px){.sgp-products{grid-template-columns:1fr}}
        .sgp-product{background:#fff;border-radius:var(--radius);overflow:hidden;box-shadow:var(--shadow);cursor:pointer;transition:all 0.2s}
        .sgp-product:hover{transform:translateY(-4px);box-shadow:0 8px 20px rgba(0,0,0,0.12)}
        .sgp-product-img{height:90px;background:linear-gradient(135deg,#fff5eb,#ffe4cc);display:flex;align-items:center;justify-content:center;font-size:40px}
        .sgp-product-img img{width:100%;height:100%;object-fit:cover}
        .sgp-product-info{padding:12px}
        .sgp-product-name{font-size:13px;font-weight:600;margin-bottom:4px;line-height:1.3}
        .sgp-product-price{font-size:18px;font-weight:700;color:var(--primary)}
        .sgp-product-price span{font-size:10px;font-weight:400;color:var(--text-light)}

        /* ========== PRODUCT MODAL ========== */
        .sgp-product-modal{display:none;position:fixed;inset:0;background:rgba(0,0,0,0.6);z-index:1000;align-items:flex-end;justify-content:center}
        .sgp-product-modal.show{display:flex}
        .sgp-product-modal-content{background:#fff;border-radius:24px 24px 0 0;padding:24px;width:100%;max-width:500px;max-height:80vh;overflow-y:auto}
        .sgp-modal-close{position:absolute;top:16px;right:16px;background:none;border:none;font-size:28px;cursor:pointer;color:var(--text-light)}
        .sgp-product-detail-img{height:150px;background:linear-gradient(135deg,#fff5eb,#ffe4cc);border-radius:var(--radius);display:flex;align-items:center;justify-content:center;font-size:60px;margin-bottom:16px}
        .sgp-product-detail-name{font-size:20px;font-weight:700;margin-bottom:8px}
        .sgp-product-detail-price{font-size:28px;font-weight:700;color:var(--primary);margin-bottom:12px}
        .sgp-product-detail-desc{font-size:14px;color:var(--text-light);margin-bottom:16px;line-height:1.6}
        .sgp-product-variations{background:var(--bg);padding:12px;border-radius:var(--radius);margin-bottom:16px;font-size:13px}

        /* ========== CONTACT - BRIGHT COLORS ========== */
        .sgp-contact-card{display:flex;align-items:center;gap:14px;padding:16px;background:#fff;border-radius:var(--radius);margin-bottom:12px;box-shadow:var(--shadow);text-decoration:none;color:var(--text);transition:all 0.2s}
        .sgp-contact-card:hover{transform:translateX(4px);box-shadow:0 4px 12px rgba(0,0,0,0.1)}
        .sgp-contact-icon{width:50px;height:50px;border-radius:14px;display:flex;align-items:center;justify-content:center;font-size:24px}
        .sgp-contact-icon.phone{background:#dbeafe;color:#2563eb}
        .sgp-contact-icon.email{background:#fce7f3;color:#db2777}
        .sgp-contact-icon.whatsapp{background:#d1fae5;color:#059669}
        .sgp-contact-icon.location{background:#fef3c7;color:#d97706}
        .sgp-contact-text h4{font-size:14px;font-weight:600;margin-bottom:2px}
        .sgp-contact-text p{font-size:14px;color:var(--primary);font-weight:500}
        
        /* BRIGHT BANKING DETAILS */
        .sgp-bank{background:linear-gradient(135deg,var(--primary),var(--primary-light));color:#fff;border-radius:var(--radius);padding:20px;margin-top:20px;box-shadow:0 4px 15px rgba(255,102,0,0.3)}
        .sgp-bank h4{font-size:16px;margin-bottom:16px;display:flex;align-items:center;gap:8px}
        .sgp-bank-row{display:flex;justify-content:space-between;padding:12px 0;border-bottom:1px solid rgba(255,255,255,0.2);font-size:14px}
        .sgp-bank-row:last-child{border:none}
        .sgp-bank-row span:first-child{opacity:0.8}
        .sgp-bank-row span:last-child{font-weight:600}

        /* ========== TRACK ========== */
        .sgp-track-box{background:#fff;border-radius:var(--radius);padding:20px;box-shadow:var(--shadow)}
        .sgp-track-form{display:flex;gap:10px;margin-top:16px}
        .sgp-track-form input{flex:1;padding:14px;border:2px solid var(--border);border-radius:12px;font-size:14px}
        .sgp-track-form input:focus{outline:none;border-color:var(--primary)}
        .sgp-track-result{margin-top:20px;padding:16px;background:var(--bg);border-radius:var(--radius)}
        .sgp-status{display:inline-block;padding:6px 14px;border-radius:20px;font-size:12px;font-weight:600;text-transform:uppercase}
        .sgp-status-pending{background:#fef3c7;color:#d97706}
        .sgp-status-processing{background:#dbeafe;color:#2563eb}
        .sgp-status-completed{background:#d1fae5;color:#059669}

        /* ========== DASHBOARD ========== */
        .sgp-stats{display:grid;grid-template-columns:repeat(2,1fr);gap:12px;margin-bottom:20px}
        .sgp-stat{background:#fff;border-radius:var(--radius);padding:20px;text-align:center;box-shadow:var(--shadow)}
        .sgp-stat-val{font-size:32px;font-weight:700;color:var(--primary)}
        .sgp-stat-label{font-size:12px;color:var(--text-light);text-transform:uppercase}
        .sgp-card{background:#fff;border-radius:var(--radius);padding:20px;box-shadow:var(--shadow);margin-bottom:16px}
        .sgp-card-title{font-size:16px;font-weight:700;margin-bottom:14px;display:flex;align-items:center;gap:8px}
        .sgp-quote-item{display:flex;justify-content:space-between;align-items:center;padding:12px 0;border-bottom:1px solid var(--border)}
        .sgp-quote-item:last-child{border:none}

        /* ========== QUOTE FORM ========== */
        .sgp-quote-form{background:#fff;border-radius:var(--radius);padding:20px;margin-top:16px;box-shadow:var(--shadow);display:none}
        .sgp-quote-summary{background:linear-gradient(135deg,#f0fdf4,#dcfce7);border:2px solid var(--success);border-radius:12px;padding:14px;margin-bottom:16px}
        .sgp-quote-summary h4{color:var(--success);font-size:14px;margin-bottom:10px}
        .sgp-summary-item{display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px dashed #a7f3d0;font-size:13px}
        .sgp-quote-total{background:var(--success);color:#fff;padding:12px 16px;border-radius:10px;display:flex;justify-content:space-between;font-weight:700;margin-top:10px}
        .sgp-form-group{margin-bottom:14px}
        .sgp-form-group label{display:block;font-size:12px;font-weight:600;color:var(--text-light);margin-bottom:6px;text-transform:uppercase}
        .sgp-form-group input{width:100%;padding:12px 14px;border:2px solid var(--border);border-radius:10px;font-size:14px}
        .sgp-form-group input:focus{outline:none;border-color:var(--primary)}

        /* ========== LOGIN/REGISTER MODAL ========== */
        .sgp-modal{display:none;position:fixed;inset:0;background:rgba(0,0,0,0.5);z-index:1000;align-items:center;justify-content:center;padding:20px}
        .sgp-modal.show{display:flex}
        .sgp-modal-box{background:#fff;border-radius:var(--radius);padding:24px;width:100%;max-width:380px}
        .sgp-modal-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:20px}
        .sgp-modal-header h3{font-size:20px;font-weight:700}
        .sgp-modal-close-btn{background:none;border:none;font-size:28px;cursor:pointer;color:var(--text-light)}
        .sgp-tabs{display:flex;background:var(--bg);border-radius:10px;padding:4px;margin-bottom:20px}
        .sgp-tab{flex:1;padding:10px;border:none;background:none;font-size:14px;font-weight:600;color:var(--text-light);cursor:pointer;border-radius:8px}
        .sgp-tab.active{background:#fff;color:var(--primary);box-shadow:var(--shadow)}
        .sgp-form-error{background:#fef2f2;color:#dc2626;padding:10px 14px;border-radius:8px;font-size:13px;margin-bottom:14px;display:none}
        .sgp-form-success{background:#f0fdf4;color:#16a34a;padding:10px 14px;border-radius:8px;font-size:13px;margin-bottom:14px;display:none}
        .sgp-loading{display:inline-block;width:18px;height:18px;border:2px solid rgba(255,255,255,0.3);border-radius:50%;border-top-color:#fff;animation:spin 0.8s linear infinite}
        @keyframes spin{to{transform:rotate(360deg)}}
        </style>

        <div class="sgp">
            <!-- HEADER - ORANGE TEXT -->
            <header class="sgp-header">
                <h1>Switch Graphics (Pty) Ltd</h1>
                <p>Reg: 2022/631744/07 | CSD: MAAA1579506</p>
                <div class="sgp-header-btns">
                    <?php if ($is_logged_in): ?>
                        <div class="sgp-user-pill">
                            <div class="sgp-user-avatar"><?php echo strtoupper(substr($customer['first_name'], 0, 1)); ?></div>
                            <span><?php echo esc_html($customer['first_name']); ?></span>
                        </div>
                        <button class="sgp-btn sgp-btn-outline" onclick="sgpLogout()">Logout</button>
                    <?php else: ?>
                        <button class="sgp-btn sgp-btn-primary" onclick="sgpShowAuth('login')">Login</button>
                        <button class="sgp-btn sgp-btn-outline" onclick="sgpShowAuth('register')">Register</button>
                    <?php endif; ?>
                </div>
            </header>

            <!-- AI CHAT - WORKS FOR EVERYONE -->
            <section class="sgp-ai">
                <div class="sgp-ai-header">
                    <div class="sgp-ai-icon">💬</div>
                    <div>
                        <h2>Get an Instant Quote</h2>
                        <p>Chat with our AI to get pricing instantly</p>
                    </div>
                </div>
                <div class="sgp-chat" id="sgpChat">
                    <div class="sgp-msg sgp-msg-ai">
                        <strong>Hi there! 👋</strong><br><br>
                        Welcome to Switch Graphics! I'm here to help you get a quick quote for any printing needs.<br><br>
                        What can I help you with today?
                        <div class="sgp-quick">
                            <button class="sgp-quick-btn" onclick="sgpSend('Business Cards')">💳 Business Cards</button>
                            <button class="sgp-quick-btn" onclick="sgpSend('Flyers')">📄 Flyers</button>
                            <button class="sgp-quick-btn" onclick="sgpSend('Banners')">🎪 Banners</button>
                            <button class="sgp-quick-btn" onclick="sgpSend('T-Shirts')">👕 Apparel</button>
                        </div>
                    </div>
                </div>
                <div class="sgp-input-row">
                    <input type="text" id="sgpInput" placeholder="Type your message..." autocomplete="off">
                    <button onclick="sgpSendInput()">➤</button>
                </div>

                <!-- Quote Form (shows when AI conversation complete) -->
                <div class="sgp-quote-form" id="sgpQuoteForm">
                    <h3 style="font-size:16px;margin-bottom:14px">📋 Complete Your Quote</h3>
                    <div class="sgp-quote-summary" id="sgpQuoteSummary"></div>
                    
                    <?php if (!$is_logged_in): ?>
                    <p style="font-size:13px;color:var(--text-light);margin-bottom:14px">Enter your details to receive your quote. An account will be created for you.</p>
                    <div class="sgp-form-group">
                        <label>Full Name *</label>
                        <input type="text" id="qfName" placeholder="John Doe">
                    </div>
                    <div class="sgp-form-group">
                        <label>WhatsApp Number *</label>
                        <input type="tel" id="qfPhone" placeholder="0681234567">
                    </div>
                    <div class="sgp-form-group">
                        <label>Email (optional)</label>
                        <input type="email" id="qfEmail" placeholder="you@email.com">
                    </div>
                    <div class="sgp-form-group">
                        <label>Create Password *</label>
                        <input type="password" id="qfPass" placeholder="Choose a password">
                    </div>
                    <?php else: ?>
                    <input type="hidden" id="qfName" value="<?php echo esc_attr($customer['first_name'].' '.$customer['last_name']); ?>">
                    <input type="hidden" id="qfPhone" value="<?php echo esc_attr($customer['cell_number']); ?>">
                    <input type="hidden" id="qfEmail" value="<?php echo esc_attr($customer['email']); ?>">
                    <input type="hidden" id="qfPass" value="">
                    <p style="font-size:14px;margin-bottom:14px">Submitting quote as <strong><?php echo esc_html($customer['first_name']); ?></strong></p>
                    <?php endif; ?>
                    
                    <button class="sgp-btn sgp-btn-primary" style="width:100%" onclick="sgpSubmitQuote()">✅ Submit Quote Request</button>
                </div>
            </section>

            <!-- PANELS -->

            <!-- DASHBOARD (logged in users) -->
            <?php if ($is_logged_in): ?>
            <div class="sgp-panel active" id="panelDashboard">
                <h2 style="font-size:20px;font-weight:700;margin-bottom:16px">👋 Welcome, <?php echo esc_html($customer['first_name']); ?>!</h2>
                <div class="sgp-stats">
                    <div class="sgp-stat">
                        <div class="sgp-stat-val"><?php echo intval($stats['quotes']); ?></div>
                        <div class="sgp-stat-label">Quotes</div>
                    </div>
                    <div class="sgp-stat">
                        <div class="sgp-stat-val">24/7</div>
                        <div class="sgp-stat-label">Support</div>
                    </div>
                </div>
                
                <div class="sgp-card">
                    <div class="sgp-card-title">📋 Your Quotes</div>
                    <?php
                    $quotes = $wpdb->get_results($wpdb->prepare(
                        "SELECT * FROM {$wpdb->prefix}sbha_quotes WHERE customer_id = %d ORDER BY created_at DESC LIMIT 5",
                        $customer['id']
                    ));
                    if ($quotes): foreach ($quotes as $q): ?>
                    <div class="sgp-quote-item">
                        <div>
                            <strong><?php echo esc_html($q->quote_number); ?></strong>
                            <div style="font-size:12px;color:var(--text-light)"><?php echo date('d M Y', strtotime($q->created_at)); ?></div>
                        </div>
                        <span class="sgp-status sgp-status-<?php echo esc_attr($q->status); ?>"><?php echo esc_html($q->status); ?></span>
                    </div>
                    <?php endforeach; else: ?>
                    <p style="color:var(--text-light);font-size:14px;text-align:center;padding:20px 0">No quotes yet. Start a conversation above!</p>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>

            <!-- SHOP -->
            <div class="sgp-panel <?php echo !$is_logged_in ? 'active' : ''; ?>" id="panelShop">
                <div class="sgp-shop-header">
                    <span style="font-size:28px">🛍️</span>
                    <h2>Our Products</h2>
                </div>
                
                <div class="sgp-filters">
                    <button class="sgp-filter active" data-cat="all">All</button>
                    <?php foreach ($categories as $key => $cat): ?>
                    <button class="sgp-filter" data-cat="<?php echo esc_attr($key); ?>"><?php echo esc_html($cat['emoji'].' '.$cat['name']); ?></button>
                    <?php endforeach; ?>
                </div>
                
                <div class="sgp-products">
                    <?php foreach ($products as $key => $product): 
                        $img = get_option('sbha_product_image_'.$key, '');
                        $cat_icon = isset($categories[$product['category']]) ? $categories[$product['category']]['emoji'] : '📦';
                    ?>
                    <div class="sgp-product" data-cat="<?php echo esc_attr($product['category']); ?>" data-key="<?php echo esc_attr($key); ?>" onclick="sgpShowProduct('<?php echo esc_js($key); ?>')">
                        <div class="sgp-product-img">
                            <?php if ($img): ?>
                                <img src="<?php echo esc_url($img); ?>" alt="<?php echo esc_attr($product['name']); ?>">
                            <?php else: ?>
                                <?php echo esc_html($cat_icon); ?>
                            <?php endif; ?>
                        </div>
                        <div class="sgp-product-info">
                            <div class="sgp-product-name"><?php echo esc_html($product['name']); ?></div>
                            <div class="sgp-product-price">R<?php echo number_format($product['price'], 2); ?> <span>from</span></div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- TRACK -->
            <div class="sgp-panel" id="panelTrack">
                <div class="sgp-track-box">
                    <h2 style="font-size:20px;font-weight:700;margin-bottom:8px">📦 Track Your Order</h2>
                    <p style="color:var(--text-light);font-size:14px">Enter your invoice number to check status</p>
                    <div class="sgp-track-form">
                        <input type="text" id="trackInput" placeholder="e.g. INV-SBH001">
                        <button class="sgp-btn sgp-btn-primary" onclick="sgpTrack()">Track</button>
                    </div>
                    <div id="trackResult"></div>
                </div>
            </div>

            <!-- CONTACT - BRIGHT COLORS -->
            <div class="sgp-panel" id="panelContact">
                <h2 style="font-size:20px;font-weight:700;margin-bottom:16px">📞 Contact Us</h2>
                
                <a href="tel:0681474232" class="sgp-contact-card">
                    <div class="sgp-contact-icon phone">📞</div>
                    <div class="sgp-contact-text">
                        <h4>Call Us</h4>
                        <p>068 147 4232</p>
                    </div>
                </a>

                <a href="mailto:tinashe@switchgraphics.co.za" class="sgp-contact-card">
                    <div class="sgp-contact-icon email">✉️</div>
                    <div class="sgp-contact-text">
                        <h4>Email Us</h4>
                        <p>tinashe@switchgraphics.co.za</p>
                    </div>
                </a>

                <a href="https://wa.me/27681474232" target="_blank" class="sgp-contact-card">
                    <div class="sgp-contact-icon whatsapp">💬</div>
                    <div class="sgp-contact-text">
                        <h4>WhatsApp</h4>
                        <p>Chat on WhatsApp</p>
                    </div>
                </a>

                <a href="https://maps.google.com/?q=16+Harding+Street+Newcastle+2940" target="_blank" class="sgp-contact-card">
                    <div class="sgp-contact-icon location">📍</div>
                    <div class="sgp-contact-text">
                        <h4>Visit Us</h4>
                        <p>16 Harding Street, Newcastle, 2940</p>
                    </div>
                </a>

                <!-- BRIGHT BANKING -->
                <div class="sgp-bank">
                    <h4>🏦 Banking Details</h4>
                    <div class="sgp-bank-row"><span>Bank</span><span>FNB/RMB</span></div>
                    <div class="sgp-bank-row"><span>Account Name</span><span>Switch Graphics (Pty) Ltd</span></div>
                    <div class="sgp-bank-row"><span>Account Type</span><span>Gold Business Account</span></div>
                    <div class="sgp-bank-row"><span>Account No.</span><span>630 842 187 18</span></div>
                    <div class="sgp-bank-row"><span>Branch Code</span><span>250 655</span></div>
                </div>
            </div>

            <!-- BOTTOM NAV -->
            <nav class="sgp-nav">
                <?php if ($is_logged_in): ?>
                <button class="sgp-nav-btn active" onclick="sgpPanel('panelDashboard',this)">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/></svg>
                    Home
                </button>
                <?php endif; ?>
                <button class="sgp-nav-btn <?php echo !$is_logged_in ? 'active' : ''; ?>" onclick="sgpPanel('panelShop',this)">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"/></svg>
                    Shop
                </button>
                <button class="sgp-nav-btn" onclick="sgpPanel('panelTrack',this)">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/></svg>
                    Track
                </button>
                <button class="sgp-nav-btn" onclick="sgpPanel('panelContact',this)">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"/></svg>
                    Contact
                </button>
            </nav>

            <!-- PRODUCT MODAL -->
            <div class="sgp-product-modal" id="productModal">
                <div class="sgp-product-modal-content">
                    <button class="sgp-modal-close" onclick="sgpCloseProduct()">&times;</button>
                    <div id="productModalBody"></div>
                </div>
            </div>

            <!-- LOGIN/REGISTER MODAL -->
            <div class="sgp-modal" id="authModal">
                <div class="sgp-modal-box">
                    <div class="sgp-modal-header">
                        <h3 id="authTitle">Login</h3>
                        <button class="sgp-modal-close-btn" onclick="sgpCloseAuth()">&times;</button>
                    </div>
                    <div class="sgp-tabs">
                        <button class="sgp-tab active" onclick="sgpAuthTab('login')">Login</button>
                        <button class="sgp-tab" onclick="sgpAuthTab('register')">Register</button>
                    </div>
                    <div class="sgp-form-error" id="authError"></div>
                    <div class="sgp-form-success" id="authSuccess"></div>
                    
                    <!-- Login -->
                    <div id="loginForm">
                        <div class="sgp-form-group">
                            <label>Phone Number</label>
                            <input type="tel" id="loginPhone" placeholder="0681234567">
                        </div>
                        <div class="sgp-form-group">
                            <label>Password</label>
                            <input type="password" id="loginPass">
                        </div>
                        <button class="sgp-btn sgp-btn-primary" style="width:100%" onclick="sgpLogin()">Login</button>
                    </div>
                    
                    <!-- Register - PHONE ONLY -->
                    <div id="registerForm" style="display:none">
                        <div class="sgp-form-group">
                            <label>Full Name *</label>
                            <input type="text" id="regName" placeholder="John Doe">
                        </div>
                        <div class="sgp-form-group">
                            <label>WhatsApp Number *</label>
                            <input type="tel" id="regPhone" placeholder="0681234567">
                        </div>
                        <div class="sgp-form-group">
                            <label>Email (optional)</label>
                            <input type="email" id="regEmail" placeholder="you@email.com">
                        </div>
                        <div class="sgp-form-group">
                            <label>Password *</label>
                            <input type="password" id="regPass">
                        </div>
                        <button class="sgp-btn sgp-btn-primary" style="width:100%" onclick="sgpRegister()">Create Account</button>
                    </div>
                </div>
            </div>
        </div>

        <script>
        (function(){
            const ajax = '<?php echo esc_js($ajax_url); ?>';
            const nonce = '<?php echo esc_js($nonce); ?>';
            const isLoggedIn = <?php echo $is_logged_in ? 'true' : 'false'; ?>;
            let aiContext = {};
            let quoteData = null;
            
            // Product data
            const products = <?php echo json_encode($products); ?>;
            const categories = <?php echo json_encode($categories); ?>;

            // Panel switch
            window.sgpPanel = function(id, btn) {
                document.querySelectorAll('.sgp-panel').forEach(p => p.classList.remove('active'));
                document.querySelectorAll('.sgp-nav-btn').forEach(b => b.classList.remove('active'));
                document.getElementById(id).classList.add('active');
                if(btn) btn.classList.add('active');
            };

            // Product filter
            document.querySelectorAll('.sgp-filter').forEach(btn => {
                btn.addEventListener('click', function() {
                    const cat = this.dataset.cat;
                    document.querySelectorAll('.sgp-filter').forEach(b => b.classList.remove('active'));
                    this.classList.add('active');
                    document.querySelectorAll('.sgp-product').forEach(p => {
                        p.style.display = (cat === 'all' || p.dataset.cat === cat) ? 'block' : 'none';
                    });
                });
            });

            // Show product modal
            window.sgpShowProduct = function(key) {
                const p = products[key];
                if(!p) return;
                const icon = categories[p.category]?.emoji || '📦';
                const img = ''; // get_option would be server-side
                
                document.getElementById('productModalBody').innerHTML = `
                    <div class="sgp-product-detail-img">${icon}</div>
                    <div class="sgp-product-detail-name">${p.name}</div>
                    <div class="sgp-product-detail-price">R${p.price.toFixed(2)}</div>
                    <div class="sgp-product-detail-desc">${p.description}</div>
                    <div class="sgp-product-variations">
                        <strong>Options:</strong> ${p.variations}
                    </div>
                    <button class="sgp-btn sgp-btn-primary" style="width:100%" onclick="sgpSend('I need ${p.name}'); sgpCloseProduct();">
                        💬 Get Quote for ${p.name}
                    </button>
                `;
                document.getElementById('productModal').classList.add('show');
            };

            window.sgpCloseProduct = function() {
                document.getElementById('productModal').classList.remove('show');
            };

            // AI Chat - WORKS FOR EVERYONE
            window.sgpSend = function(msg) {
                if (!msg.trim()) return;
                addMsg(msg, 'user');
                document.getElementById('sgpInput').value = '';
                
                const typingId = 'typing-' + Date.now();
                addMsg('<span class="sgp-loading"></span> Typing...', 'ai', typingId);

                fetch(ajax, {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: new URLSearchParams({
                        action: 'sbha_ai_chat',
                        nonce: nonce,
                        message: msg,
                        context: JSON.stringify(aiContext)
                    })
                })
                .then(r => r.json())
                .then(data => {
                    document.getElementById(typingId)?.remove();
                    if (data.success) {
                        aiContext = data.data.context || {};
                        let html = data.data.message;
                        
                        if (data.data.buttons && data.data.buttons.length > 0) {
                            html += '<div class="sgp-quick">';
                            data.data.buttons.forEach(b => {
                                if (b.value === 'whatsapp') {
                                    html += '<a href="https://wa.me/27681474232" target="_blank" class="sgp-quick-btn">💬 WhatsApp</a>';
                                } else {
                                    html += '<button class="sgp-quick-btn" onclick="sgpSend(\'' + b.value.replace(/'/g, "\\'") + '\')">' + b.text + '</button>';
                                }
                            });
                            html += '</div>';
                        }
                        
                        addMsg(html, 'ai');
                        
                        if (data.data.show_quote_form && data.data.quote_data) {
                            quoteData = data.data.quote_data;
                            showQuoteForm(quoteData);
                        }
                    } else {
                        addMsg('Sorry, something went wrong. Please try again or use our WhatsApp.', 'ai');
                    }
                })
                .catch(() => {
                    document.getElementById(typingId)?.remove();
                    addMsg('Connection error. Please try again.', 'ai');
                });
            };

            window.sgpSendInput = function() {
                const input = document.getElementById('sgpInput');
                if (input.value.trim()) sgpSend(input.value);
            };

            document.getElementById('sgpInput').addEventListener('keypress', e => {
                if (e.key === 'Enter') sgpSendInput();
            });

            function addMsg(content, type, id) {
                const chat = document.getElementById('sgpChat');
                const div = document.createElement('div');
                div.className = 'sgp-msg sgp-msg-' + type;
                if (id) div.id = id;
                div.innerHTML = content;
                chat.appendChild(div);
                chat.scrollTop = chat.scrollHeight;
            }

            function showQuoteForm(data) {
                const form = document.getElementById('sgpQuoteForm');
                const summary = document.getElementById('sgpQuoteSummary');
                
                let html = '<h4>📦 Order Summary</h4>';
                let total = 0;
                
                if (data.items && data.items.length) {
                    data.items.forEach(item => {
                        const itemTotal = (item.unit_price || item.price || 0) * (item.quantity || 1);
                        total += itemTotal;
                        html += '<div class="sgp-summary-item"><span>' + item.product_name + ' (' + (item.quantity || 1) + 'x)</span><span>R' + itemTotal.toFixed(2) + '</span></div>';
                    });
                }
                
                if (data.estimate_total) total = data.estimate_total;
                html += '<div class="sgp-quote-total"><span>Estimated Total</span><span>R' + total.toFixed(2) + '</span></div>';
                
                summary.innerHTML = html;
                form.style.display = 'block';
                form.scrollIntoView({behavior: 'smooth'});
            }

            // Submit Quote - Creates account if needed
            window.sgpSubmitQuote = function() {
                const name = document.getElementById('qfName').value.trim();
                const phone = document.getElementById('qfPhone').value.trim();
                const email = document.getElementById('qfEmail')?.value?.trim() || '';
                const pass = document.getElementById('qfPass')?.value || '';
                
                if (!name || !phone) {
                    alert('Please enter your name and WhatsApp number');
                    return;
                }
                
                if (!isLoggedIn && !pass) {
                    alert('Please create a password for your account');
                    return;
                }

                const btn = event.target;
                btn.innerHTML = '<span class="sgp-loading"></span> Submitting...';
                btn.disabled = true;

                fetch(ajax, {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: new URLSearchParams({
                        action: 'sbha_submit_quote',
                        nonce: nonce,
                        name: name,
                        phone: phone,
                        email: email,
                        password: pass,
                        quote_data: JSON.stringify(quoteData || aiContext),
                        transcript: JSON.stringify(aiContext.messages || [])
                    })
                })
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        document.getElementById('sgpQuoteForm').innerHTML = `
                            <div style="text-align:center;padding:24px">
                                <div style="font-size:60px;margin-bottom:12px">✅</div>
                                <h3 style="margin-bottom:8px">Quote Submitted!</h3>
                                <p style="color:var(--primary);font-size:18px;font-weight:600">${data.data.quote_number}</p>
                                <p style="color:var(--text-light);margin-top:8px">We'll contact you on WhatsApp shortly!</p>
                            </div>
                        `;
                        addMsg('🎉 Quote submitted! Reference: <strong>' + data.data.quote_number + '</strong><br><br>We\'ll WhatsApp you shortly with your quote!', 'ai');
                        
                        // Reload if account was created
                        if (data.data.account_created) {
                            setTimeout(() => location.reload(), 2000);
                        }
                    } else {
                        alert(data.data || 'Error submitting quote. Please try again.');
                        btn.innerHTML = '✅ Submit Quote Request';
                        btn.disabled = false;
                    }
                })
                .catch(() => {
                    alert('Connection error. Please try again.');
                    btn.innerHTML = '✅ Submit Quote Request';
                    btn.disabled = false;
                });
            };

            // Track order
            window.sgpTrack = function() {
                const inv = document.getElementById('trackInput').value.trim();
                if (!inv) { alert('Enter your invoice number'); return; }
                
                fetch(ajax, {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: new URLSearchParams({ action: 'sbha_track_order', nonce: nonce, invoice: inv })
                })
                .then(r => r.json())
                .then(data => {
                    const result = document.getElementById('trackResult');
                    if (data.success) {
                        result.innerHTML = `
                            <div class="sgp-track-result">
                                <h4 style="font-size:18px;margin-bottom:8px">${data.data.invoice_number}</h4>
                                <span class="sgp-status sgp-status-${data.data.status}">${data.data.status}</span>
                                <p style="margin-top:12px;color:var(--text-light)">${data.data.date}</p>
                                <p style="margin-top:8px">${data.data.description || ''}</p>
                            </div>
                        `;
                    } else {
                        result.innerHTML = '<div class="sgp-track-result" style="text-align:center"><div style="font-size:48px">🔍</div><p>Order not found. Check your invoice number.</p></div>';
                    }
                });
            };

            // Auth modal
            window.sgpShowAuth = function(tab) {
                document.getElementById('authModal').classList.add('show');
                sgpAuthTab(tab);
            };
            
            window.sgpCloseAuth = function() {
                document.getElementById('authModal').classList.remove('show');
            };
            
            window.sgpAuthTab = function(tab) {
                document.querySelectorAll('.sgp-tab').forEach((t,i) => t.classList.toggle('active', i === (tab === 'login' ? 0 : 1)));
                document.getElementById('loginForm').style.display = tab === 'login' ? 'block' : 'none';
                document.getElementById('registerForm').style.display = tab === 'register' ? 'block' : 'none';
                document.getElementById('authTitle').textContent = tab === 'login' ? 'Login' : 'Register';
                document.getElementById('authError').style.display = 'none';
                document.getElementById('authSuccess').style.display = 'none';
            };

            // Login with PHONE
            window.sgpLogin = function() {
                const phone = document.getElementById('loginPhone').value.trim();
                const pass = document.getElementById('loginPass').value;
                if (!phone || !pass) { showAuthError('Enter phone and password'); return; }

                fetch(ajax, {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: new URLSearchParams({ action: 'sbha_login', phone: phone, password: pass })
                })
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        showAuthSuccess('Login successful! Refreshing...');
                        setTimeout(() => location.reload(), 1000);
                    } else {
                        showAuthError(data.data || 'Invalid phone or password');
                    }
                });
            };

            // Register - PHONE ONLY required
            window.sgpRegister = function() {
                const name = document.getElementById('regName').value.trim();
                const phone = document.getElementById('regPhone').value.trim();
                const email = document.getElementById('regEmail').value.trim();
                const pass = document.getElementById('regPass').value;
                
                if (!name || !phone || !pass) {
                    showAuthError('Fill in name, WhatsApp number and password');
                    return;
                }

                fetch(ajax, {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: new URLSearchParams({
                        action: 'sbha_register',
                        name: name,
                        phone: phone,
                        email: email,
                        password: pass
                    })
                })
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        showAuthSuccess('Account created! Logging in...');
                        setTimeout(() => location.reload(), 1000);
                    } else {
                        showAuthError(data.data || 'Registration failed');
                    }
                });
            };

            // Logout
            window.sgpLogout = function() {
                fetch(ajax, {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: new URLSearchParams({ action: 'sbha_logout' })
                }).then(() => location.reload());
            };

            function showAuthError(msg) {
                const el = document.getElementById('authError');
                el.textContent = msg;
                el.style.display = 'block';
                document.getElementById('authSuccess').style.display = 'none';
            }
            
            function showAuthSuccess(msg) {
                const el = document.getElementById('authSuccess');
                el.textContent = msg;
                el.style.display = 'block';
                document.getElementById('authError').style.display = 'none';
            }

            // Close modals on backdrop click
            document.getElementById('productModal').addEventListener('click', function(e) {
                if (e.target === this) sgpCloseProduct();
            });
            document.getElementById('authModal').addEventListener('click', function(e) {
                if (e.target === this) sgpCloseAuth();
            });
        })();
        </script>
        <?php
        return ob_get_clean();
    }

    private function get_logged_in_customer() {
        global $wpdb;
        $token = isset($_COOKIE['sbha_token']) ? $_COOKIE['sbha_token'] : '';
        if (!$token) return null;

        $session = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}sbha_sessions WHERE session_token = %s AND expires_at > NOW()",
            $token
        ));
        if (!$session) return null;

        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}sbha_customers WHERE id = %d AND status = 'active'",
            $session->customer_id
        ), ARRAY_A);
    }
}
