# Changelog

All notable changes to Switch Business Hub AI will be documented in this file.

## [2.2.1] - 2026-02-18

### 🔧 Stability and UX Fixes

- Fixed quote/invoice submit flow to avoid hard nonce failures on cached mobile pages
- Added resilient AJAX JSON parsing in portal JS to prevent generic "Network error" popups
- Made AI quote submit fields optional for low-friction customer flow (auto guest identity fallback)

### 📄 Invoice/Quote Visibility and Downloads

- Added public document endpoint by invoice/quote number for **View** and **Download**
- Auto-generates and stores document files for new invoices/quotes in uploads
- Added customer dashboard document controls (Open / Download)
- Added admin dashboard document controls (View / Download + total/status edits)

### 🛒 Cart and WhatsApp Ordering

- Added **Send Order to WhatsApp** in cart with full order summary and banking details
- Added WhatsApp handoff button after invoice creation confirmation

### 🧩 Dashboard / Header / Branding

- Added shortcode single-render guard to prevent duplicate app rendering blocks
- Moved welcome block into Home panel so non-home tabs stay clean
- Added logout button in header
- Added business logo support in header and product cards
- Added super-admin branding/banking editor inside portal (no WP backend required)

### 🤖 AI Assistant Improvements

- Updated variant quick buttons to be more click-friendly and descriptive
- Expanded quick-choice behavior to reduce manual typing during product selection

### ✉️ Email Improvements

- Centralized portal email sending with safer headers and delivery logging
- Added admin/customer send-state feedback in quote/invoice responses

## [2.2.0] - 2026-02-18

### 🧠 AI + Document Flow Improvements

- Added dedicated **AI Order Assistant tab** (AI is no longer shown across all tabs)
- Fixed pack-based AI pricing logic (e.g. "100 Cards" now defaults to 1 pack, avoiding inflated totals)
- AI now marks catalog-only conversations with default **Create Invoice** behavior
- AI quote modal now allows both actions:
  - **Create Invoice** for catalog items
  - **Request Quote** for custom/exception requests

### 🛒 Checkout & Invoice Behavior

- Enabled **guest checkout** for cart invoices (name + WhatsApp, no forced account creation)
- Cart checkout remains direct invoice flow
- Guest orders can still generate invoice references for tracking

### 🎨 Premium UI / Layout Updates

- Switched to pure black app base theme and removed constrained-page look
- Added viewport-filling layout behavior for shortcode pages
- Improved premium bottom nav styling
- Added dedicated AI panel to keep app sections cleaner

### 🏭 Supplier + Catalog Expansion

- Added supplier-backed catalog entries with 75% markup model:
  - https://www.printabilitypress.co.za/
  - https://emdeebranding.co.za/
  - https://displaymania.co.za/
- Added new supplier products in print, apparel and display segments

### 🖼️ Generated Catalog Images

- Added generated branded product mockup image fallback for products without uploaded images
- Every product now has a visual display image (custom upload takes priority)

### 👑 Super Admin + Demo Data

- Added default super-admin defaults:
  - Name: Switch Graphics
  - WhatsApp: 0681474232
  - Email: tinashe@switchgraphics.co.za
  - Password: Nuclear@20#
- Added frontend **Super Admin Dashboard** panel:
  - Status updates for recent quotes/invoices
  - Quick variation price editor (no WordPress backend required for these edits)
- Installer now seeds demo quote + invoice records for layout/track testing

## [2.1.0] - 2026-02-18

### 🚀 AI Quote Flow Overhaul

- Rebuilt guided AI conversation for print/signage/design quoting
- Added wedding welcome board guidance with A1 size/material options (Correx, Forex, Perspex)
- Added custom-job fallback estimates when a product is not in the catalog
- AI now asks design-vs-own-file, delivery, due date and notes before finalizing
- Quote payload now carries richer item detail (SKU, design fee, delivery fee, file note)

### 🛍️ Product + Pricing Improvements

- Expanded catalog with additional print products and wedding signage options
- Added baseline 75% markup normalization where cost prices are available
- Added core service items:
  - Design service from R350
  - Custom jobs at R350/hour
  - Delivery from R160
- Added product image resolver so admin-assigned product images display in shop cards

### 📦 Order / Invoice / Tracking Fixes

- Fixed shop invoice creation to respect quantity correctly
- Updated invoice numbering to `INV-SBH0001` format
- Tracking now works by invoice/SBH reference and checks quote/invoice records first
- Improved tracking output for pending vs verifying payment status

### 👤 Customer Portal UX + Reliability

- Header branding now supports full business name + reg/CSD lines
- Top branding text is styled in orange, per brand request
- Contact panel now uses business options for phone/WhatsApp/email/address
- Banking panel colors improved for better visibility
- Quote submission now:
  - uses logged-in customer details automatically
  - includes AI transcript
  - supports optional multi-file upload
- Added chat history persistence endpoints and logged-in sync support

### 🛠️ Admin Enhancements

- Product manager now supports image selection/upload directly in product edit form
- Orders view now shows richer item details (SKU, design/delivery fee breakdown)
- Orders view now displays AI chat transcript when available

## [1.8.0] - 2026-01-13

### 🚀 Major Features

#### Complete AI Rebuild
- **Conversational Quote Builder**: AI guides customers step-by-step
- **Design Service Integration**: AI asks about design needs (+R350)
- **Auto-Fill Quote Form**: All AI-collected info fills the form
- **Chat Transcript Attached**: Conversation attached to quotes

#### Product Catalog with SKUs
- 25+ Product categories with variants
- Each variant has unique SKU (e.g., BC-500-DS)
- 75% markup pricing from wholesale rates
- Design Service: from R350
- Custom Jobs: R350 per hour
- Delivery: from R160

#### Customer Dashboard
- Dashboard with stats for logged-in users
- Quote and invoice history
- Guest users: Direct AI chat access

#### Company Branding
- Full company details in header
- Bank details in Contact tab
- Invoice format: INV-SBH01

### 🔧 Improvements

- ✅ Contact tab: Phone, email, WhatsApp links
- ✅ Track order: Invoice number only (not email)
- ✅ Product images: Upload via Settings > Products
- ✅ Quote form: Auto-fills from AI conversation

### 📦 Products (75% markup)

**Printing:** Business Cards R175-R613, Flyers R140-R788, Posters R61-R1050
**Signage:** Banners R158-R1138, Pull-Ups R613-R1575, X-Banners R490-R665
**Wedding:** Welcome Boards R210-R1488, Seating Charts R315-R1138
**Apparel:** T-Shirts R123-R201, Golf Shirts R210-R315, Hoodies R315-R525
**Vehicle:** Door Decals R1400+, Half Wraps R3500+, Full Wraps R7875+
**Services:** Design R350+, Custom R350/hr, Delivery R160+

---

## [1.7.0] - 2026-01-12
- Initial conversational AI
- WhatsApp integration

## [1.6.0] - 2026-01-11  
- Premium UI redesign
- Service catalog

---
**Switch Graphics (Pty) Ltd** | 068 147 4232 | www.switchgraphics.co.za
