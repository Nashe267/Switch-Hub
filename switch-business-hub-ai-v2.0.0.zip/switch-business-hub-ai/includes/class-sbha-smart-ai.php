<?php
/**
 * Switch Graphics AI v2.0 - COMPLETELY REWRITTEN
 * 
 * Simple state machine that ACTUALLY WORKS:
 * 1. User says what they need
 * 2. AI shows matching product with options
 * 3. User picks option
 * 4. AI asks quantity (if needed)
 * 5. AI asks delivery (if physical)
 * 6. AI asks if they need more
 * 7. Done = Show quote form OR submit directly if logged in
 * 
 * @package SwitchBusinessHub
 * @version 2.0.0
 */

if (!defined('ABSPATH')) exit;

class SBHA_Smart_AI {
    
    private $products;
    
    public function __construct() {
        require_once plugin_dir_path(__FILE__) . 'class-sbha-products.php';
        $this->products = SBHA_Products::get_all();
    }
    
    public function process($message, $context = array()) {
        // Initialize context
        $ctx = wp_parse_args($context, array(
            'state' => 'start',
            'current_product' => null,
            'current_variation' => null,
            'current_price' => 0,
            'current_qty' => 1,
            'is_digital' => false,
            'delivery' => '',
            'brief' => '',
            'cart' => array()
        ));
        
        $msg = strtolower(trim($message));
        $result = $this->handle_state($msg, $message, $ctx);
        
        return array(
            'message' => $result['message'],
            'buttons' => $result['buttons'] ?? array(),
            'context' => $result['context'],
            'show_quote_form' => $result['show_quote_form'] ?? false,
            'quote_data' => $result['quote_data'] ?? null
        );
    }
    
    private function handle_state($msg, $original, $ctx) {
        // Check for DONE/FINALIZE at any point
        if (preg_match('/^(done|finalize|finish|submit|complete|no more|thats? all|nothing|nope)$/i', $msg)) {
            if (!empty($ctx['cart'])) {
                return $this->finalize_quote($ctx);
            }
        }
        
        // Check for ADD MORE
        if ($ctx['state'] === 'ask_more') {
            if (preg_match('/(yes|more|add|another|sure)/i', $msg)) {
                $ctx['state'] = 'start';
                return $this->greeting($ctx);
            } else {
                return $this->finalize_quote($ctx);
            }
        }
        
        // State machine
        switch ($ctx['state']) {
            case 'start':
            case 'greeting':
                return $this->find_product($msg, $ctx);
                
            case 'pick_option':
                return $this->handle_option_selection($msg, $ctx);
                
            case 'pick_qty':
                return $this->handle_quantity($msg, $ctx);
                
            case 'pick_delivery':
                return $this->handle_delivery($msg, $ctx);
                
            case 'get_address':
                return $this->handle_address($original, $ctx);
                
            case 'get_brief':
                return $this->handle_brief($original, $ctx);
                
            default:
                return $this->greeting($ctx);
        }
    }
    
    private function greeting($ctx) {
        $ctx['state'] = 'start';
        return array(
            'message' => "👋 Hi! What can I help you with today?",
            'buttons' => array(
                array('text' => '🎨 Logo Design', 'value' => 'logo design'),
                array('text' => '🌐 Website', 'value' => 'website'),
                array('text' => '💳 Business Cards', 'value' => 'business cards'),
                array('text' => '🪧 Signage', 'value' => 'signage'),
                array('text' => '📄 Flyers', 'value' => 'flyers'),
            ),
            'context' => $ctx
        );
    }
    
    private function find_product($msg, $ctx) {
        // Product keyword mapping - VERY SPECIFIC
        $keywords = array(
            'logo' => 'logo_design',
            'brand' => 'brand_package',
            'website' => 'website_starter',
            'web site' => 'website_starter',
            'landing page' => 'landing_page',
            'business card' => 'business_cards_standard',
            'card' => 'business_cards_standard',
            'flyer' => 'a5_flyers',
            'leaflet' => 'a5_flyers',
            'poster' => 'a3_posters',
            'banner' => 'pull_up_banner',
            'pull up' => 'pull_up_banner',
            'rollup' => 'pull_up_banner',
            'signage' => 'correx_board',
            'sign' => 'correx_board',
            'correx' => 'correx_board',
            'board' => 'correx_board',
            'sticker' => 'custom_stickers',
            'label' => 'custom_stickers',
            'mug' => 'branded_mugs',
            'cup' => 'branded_mugs',
            'vehicle' => 'vehicle_magnets',
            'car' => 'vehicle_magnets',
            'magnet' => 'vehicle_magnets',
            'social media' => 'social_media_design',
            'facebook' => 'social_media_design',
            'instagram' => 'social_media_design',
        );
        
        $found_key = null;
        foreach ($keywords as $keyword => $product_key) {
            if (strpos($msg, $keyword) !== false && isset($this->products[$product_key])) {
                $found_key = $product_key;
                break;
            }
        }
        
        if (!$found_key) {
            return array(
                'message' => "I can help with:\n• Logo Design\n• Websites\n• Business Cards\n• Flyers & Posters\n• Signage\n• Stickers\n• Mugs\n\nWhat do you need?",
                'buttons' => array(
                    array('text' => '🎨 Logo', 'value' => 'logo'),
                    array('text' => '🌐 Website', 'value' => 'website'),
                    array('text' => '💳 Cards', 'value' => 'business cards'),
                    array('text' => '🪧 Signage', 'value' => 'signage'),
                ),
                'context' => $ctx
            );
        }
        
        $product = $this->products[$found_key];
        
        // Determine if digital
        $name_lower = strtolower($product['name']);
        $is_digital = (
            strpos($name_lower, 'logo') !== false ||
            strpos($name_lower, 'design') !== false ||
            strpos($name_lower, 'website') !== false ||
            strpos($name_lower, 'social') !== false ||
            ($product['category'] ?? '') === 'design' ||
            ($product['category'] ?? '') === 'websites' ||
            !empty($product['is_design_service'])
        );
        
        $ctx['current_product'] = $found_key;
        $ctx['product_name'] = $product['name'];
        $ctx['is_digital'] = $is_digital;
        $ctx['state'] = 'pick_option';
        
        // Build options message
        $text = "✅ **{$product['name']}**\n\n";
        if (!empty($product['description'])) {
            $text .= "{$product['description']}\n\n";
        }
        $text .= "**Choose an option:**\n\n";
        
        $buttons = array();
        foreach ($product['variations'] as $i => $v) {
            $num = $i + 1;
            $text .= "{$num}. {$v['name']} - **R{$v['price']}**\n";
            if ($i < 4) {
                $buttons[] = array('text' => "{$num}. R{$v['price']}", 'value' => (string)$num);
            }
        }
        
        return array(
            'message' => $text,
            'buttons' => $buttons,
            'context' => $ctx
        );
    }
    
    private function handle_option_selection($msg, $ctx) {
        $product = $this->products[$ctx['current_product']] ?? null;
        if (!$product) {
            return $this->greeting($ctx);
        }
        
        // Find selected option
        $selected = null;
        
        // Try number first
        if (preg_match('/^(\d+)/', $msg, $m)) {
            $idx = intval($m[1]) - 1;
            if (isset($product['variations'][$idx])) {
                $selected = $product['variations'][$idx];
                $ctx['variation_idx'] = $idx;
            }
        }
        
        // Try text match
        if (!$selected) {
            foreach ($product['variations'] as $i => $v) {
                if (stripos($msg, strtolower($v['name'])) !== false) {
                    $selected = $v;
                    $ctx['variation_idx'] = $i;
                    break;
                }
            }
        }
        
        if (!$selected) {
            return array(
                'message' => "Please select a number (1, 2, 3, etc.)",
                'buttons' => array(),
                'context' => $ctx
            );
        }
        
        $ctx['current_variation'] = $selected['name'];
        $ctx['current_price'] = $selected['price'];
        
        // Check if variation already has quantity (e.g., "100 Business Cards")
        if (preg_match('/^\d+\s/', $selected['name'])) {
            $ctx['current_qty'] = 1;
            return $this->after_quantity($ctx);
        }
        
        // Ask quantity
        $ctx['state'] = 'pick_qty';
        return array(
            'message' => "Selected: **{$selected['name']}** - R{$selected['price']}\n\nHow many do you need?",
            'buttons' => array(
                array('text' => '1', 'value' => '1'),
                array('text' => '2', 'value' => '2'),
                array('text' => '5', 'value' => '5'),
                array('text' => '10', 'value' => '10'),
            ),
            'context' => $ctx
        );
    }
    
    private function handle_quantity($msg, $ctx) {
        preg_match('/(\d+)/', $msg, $m);
        $ctx['current_qty'] = isset($m[1]) ? max(1, intval($m[1])) : 1;
        return $this->after_quantity($ctx);
    }
    
    private function after_quantity($ctx) {
        $subtotal = $ctx['current_price'] * $ctx['current_qty'];
        
        // Digital = ask brief, no delivery
        if ($ctx['is_digital']) {
            $ctx['delivery'] = 'Digital delivery';
            $ctx['state'] = 'get_brief';
            
            return array(
                'message' => "Got it! **{$ctx['current_variation']}** - R{$subtotal}\n\n📝 Tell me about your project:\n(What's it for? Any style preferences?)",
                'buttons' => array(),
                'context' => $ctx
            );
        }
        
        // Physical = ask delivery
        $ctx['state'] = 'pick_delivery';
        return array(
            'message' => "Got it! **{$ctx['current_qty']}x {$ctx['current_variation']}** - R{$subtotal}\n\n🚚 Delivery or collection?\n📍 Shop: 16 Harding St, Newcastle",
            'buttons' => array(
                array('text' => '🚚 Deliver', 'value' => 'deliver'),
                array('text' => '🏪 Collect', 'value' => 'collect'),
            ),
            'context' => $ctx
        );
    }
    
    private function handle_delivery($msg, $ctx) {
        if (preg_match('/(deliver|ship|send)/i', $msg)) {
            $ctx['state'] = 'get_address';
            return array(
                'message' => "📍 What's your delivery address?",
                'buttons' => array(),
                'context' => $ctx
            );
        }
        
        $ctx['delivery'] = 'Collection from 16 Harding St, Newcastle';
        return $this->add_to_cart($ctx);
    }
    
    private function handle_address($msg, $ctx) {
        $ctx['delivery'] = 'Deliver to: ' . $msg;
        return $this->add_to_cart($ctx);
    }
    
    private function handle_brief($msg, $ctx) {
        $ctx['brief'] = $msg;
        return $this->add_to_cart($ctx);
    }
    
    private function add_to_cart($ctx) {
        // Add current item to cart
        $ctx['cart'][] = array(
            'product_key' => $ctx['current_product'],
            'product_name' => $ctx['product_name'],
            'variant_name' => $ctx['current_variation'],
            'quantity' => $ctx['current_qty'],
            'unit_price' => $ctx['current_price'],
            'brief' => $ctx['brief'] ?? '',
            'delivery' => $ctx['delivery'] ?? ''
        );
        
        // Reset current item
        $ctx['current_product'] = null;
        $ctx['current_variation'] = null;
        $ctx['brief'] = '';
        $ctx['delivery'] = '';
        $ctx['state'] = 'ask_more';
        
        return array(
            'message' => "✅ Added to quote!\n\n**Need anything else?**",
            'buttons' => array(
                array('text' => '➕ Add more', 'value' => 'yes add more'),
                array('text' => '✅ Done', 'value' => 'done'),
            ),
            'context' => $ctx
        );
    }
    
    private function finalize_quote($ctx) {
        if (empty($ctx['cart'])) {
            return $this->greeting($ctx);
        }
        
        $total = 0;
        $summary = "";
        
        foreach ($ctx['cart'] as $item) {
            $sub = ($item['unit_price'] ?? 0) * ($item['quantity'] ?? 1);
            $total += $sub;
            $qty = ($item['quantity'] > 1) ? "{$item['quantity']}x " : "";
            $summary .= "• {$qty}{$item['variant_name']} - R{$sub}\n";
        }
        
        $ctx['state'] = 'done';
        
        return array(
            'message' => "🎉 **Quote Summary**\n\n{$summary}\n💰 **Total: R{$total}**\n\nClick below to submit your quote!",
            'buttons' => array(),
            'context' => $ctx,
            'show_quote_form' => true,
            'quote_data' => array(
                'items' => $ctx['cart'],
                'estimate_total' => $total
            )
        );
    }
}
