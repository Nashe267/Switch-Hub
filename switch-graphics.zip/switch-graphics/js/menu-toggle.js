/**
 * Menu toggle (burger) open/close
 */
(function () {
	var toggle = document.querySelector('.menu-toggle');
	var nav = document.querySelector('.primary-menu-wrap');
	if (!toggle) return;

	toggle.addEventListener('click', function () {
		var expanded = toggle.getAttribute('aria-expanded') === 'true';
		toggle.setAttribute('aria-expanded', !expanded);
		if (nav) nav.classList.toggle('is-open');
		document.body.classList.toggle('menu-open', !expanded);
	});
})();
