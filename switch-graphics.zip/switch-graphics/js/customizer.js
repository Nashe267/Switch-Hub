/**
 * Live preview for Switch Graphics customizer
 */
(function (wp) {
	if (!wp || !wp.customize) return;

	wp.customize('switch_graphics_header_gradient_top', function (value) {
		value.bind(function (to) {
			var bottom = wp.customize('switch_graphics_header_gradient_bottom').get();
			document.querySelector('.site-header').style.background = 'linear-gradient(to bottom, ' + to + ' 0%, ' + bottom + ' 100%)';
		});
	});

	wp.customize('switch_graphics_header_gradient_bottom', function (value) {
		value.bind(function (to) {
			var top = wp.customize('switch_graphics_header_gradient_top').get();
			document.querySelector('.site-header').style.background = 'linear-gradient(to bottom, ' + top + ' 0%, ' + to + ' 100%)';
		});
	});

	wp.customize('switch_graphics_menu_fill_from', function (value) {
		value.bind(function () {
			wp.customize.previewer.refresh();
		});
	});
	wp.customize('switch_graphics_menu_fill_to', function (value) {
		value.bind(function () {
			wp.customize.previewer.refresh();
		});
	});
	wp.customize('switch_graphics_menu_outline', function (value) {
		value.bind(function () {
			wp.customize.previewer.refresh();
		});
	});

	wp.customize('switch_graphics_copyright', function (value) {
		value.bind(function (to) {
			var el = document.querySelector('.site-footer .copyright');
			if (el) el.innerHTML = to;
		});
	});

	wp.customize('switch_graphics_content_bg', function (value) {
		value.bind(function () {
			wp.customize.previewer.refresh();
		});
	});
})(window.wp);
