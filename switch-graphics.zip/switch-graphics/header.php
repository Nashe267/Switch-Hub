<?php
/**
 * Header template
 *
 * @package Switch_Graphics
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<header id="masthead" class="site-header">
	<div class="header-inner">
		<div class="site-branding">
			<?php if ( has_custom_logo() ) : ?>
				<?php the_custom_logo(); ?>
			<?php else : ?>
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="site-title-wrap" rel="home">
					<span class="site-title-line1"><?php bloginfo( 'name' ); ?></span>
					<span class="site-title-line2"><?php echo wp_kses_post( get_bloginfo( 'description' ) ?: __( 'Graphics', 'switch-graphics' ) ); ?></span>
				</a>
			<?php endif; ?>
		</div>

		<nav id="site-navigation" class="main-navigation">
			<button type="button" class="menu-toggle" aria-controls="primary-menu" aria-expanded="false" aria-label="<?php esc_attr_e( 'Toggle menu', 'switch-graphics' ); ?>">
				<span class="bar"></span>
				<span class="bar"></span>
				<span class="bar"></span>
			</button>
			<?php
			wp_nav_menu( array(
				'theme_location' => 'primary',
				'menu_id'        => 'primary-menu',
				'menu_class'     => 'primary-menu-list',
				'container'      => 'div',
				'container_class'=> 'primary-menu-wrap',
				'fallback_cb'    => false,
			) );
			?>
		</nav>
	</div>
</header>
