<?php
/**
 * Switch Graphics Theme Customizer
 *
 * @package Switch_Graphics
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Add customizer options and output inline CSS
 */
function switch_graphics_customize_register( WP_Customize_Manager $wp_customize ) {

	/* --- Header section --- */
	$wp_customize->add_section( 'switch_graphics_header', array(
		'title'    => __( 'Header', 'switch-graphics' ),
		'priority' => 30,
	) );

	// Header gradient top color
	$wp_customize->add_setting( 'switch_graphics_header_gradient_top', array(
		'default'           => '#000000',
		'sanitize_callback' => 'sanitize_hex_color',
		'transport'         => 'postMessage',
	) );
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'switch_graphics_header_gradient_top', array(
		'label'   => __( 'Header gradient (top)', 'switch-graphics' ),
		'section' => 'switch_graphics_header',
	) ) );

	// Header gradient bottom color (with opacity)
	$wp_customize->add_setting( 'switch_graphics_header_gradient_bottom', array(
		'default'           => 'rgba(0,0,0,0.25)',
		'sanitize_callback' => 'switch_graphics_sanitize_rgba',
		'transport'         => 'postMessage',
	) );
	$wp_customize->add_control( 'switch_graphics_header_gradient_bottom', array(
		'type'        => 'text',
		'label'       => __( 'Header gradient (bottom) — e.g. rgba(0,0,0,0.25)', 'switch-graphics' ),
		'description' => __( 'Use rgba for opacity. Default: black at 25%', 'switch-graphics' ),
		'section'     => 'switch_graphics_header',
	) );

	/* --- Logo (uses core custom_logo; move into Header section) --- */
	$logo_control = $wp_customize->get_control( 'custom_logo' );
	if ( $logo_control ) {
		$logo_control->section = 'switch_graphics_header';
	}

	/* --- Menu icon section --- */
	$wp_customize->add_section( 'switch_graphics_menu_icon', array(
		'title'    => __( 'Menu icon (burger)', 'switch-graphics' ),
		'priority' => 35,
	) );

	// Menu icon fill — gradient (from / to)
	$wp_customize->add_setting( 'switch_graphics_menu_fill_from', array(
		'default'           => '#e85d04',
		'sanitize_callback' => 'sanitize_hex_color',
		'transport'         => 'postMessage',
	) );
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'switch_graphics_menu_fill_from', array(
		'label'   => __( 'Menu icon fill (gradient start)', 'switch-graphics' ),
		'section' => 'switch_graphics_menu_icon',
	) ) );

	$wp_customize->add_setting( 'switch_graphics_menu_fill_to', array(
		'default'           => '#dc2f02',
		'sanitize_callback' => 'sanitize_hex_color',
		'transport'         => 'postMessage',
	) );
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'switch_graphics_menu_fill_to', array(
		'label'   => __( 'Menu icon fill (gradient end)', 'switch-graphics' ),
		'section' => 'switch_graphics_menu_icon',
	) ) );

	// Menu icon outline color
	$wp_customize->add_setting( 'switch_graphics_menu_outline', array(
		'default'           => '#323232',
		'sanitize_callback' => 'sanitize_hex_color',
		'transport'         => 'postMessage',
	) );
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'switch_graphics_menu_outline', array(
		'label'   => __( 'Menu icon outline color', 'switch-graphics' ),
		'section' => 'switch_graphics_menu_icon',
	) ) );

	/* --- Footer section --- */
	$wp_customize->add_section( 'switch_graphics_footer', array(
		'title'    => __( 'Footer', 'switch-graphics' ),
		'priority' => 40,
	) );

	// Copyright text
	$wp_customize->add_setting( 'switch_graphics_copyright', array(
		'default'           => '2026 © Designed & Powered By: Switch Graphics (Pty) Ltd',
		'sanitize_callback' => 'wp_kses_post',
		'transport'         => 'postMessage',
	) );
	$wp_customize->add_control( 'switch_graphics_copyright', array(
		'type'    => 'textarea',
		'label'   => __( 'Copyright text', 'switch-graphics' ),
		'section' => 'switch_graphics_footer',
	) );

	// Content/footer area background (used to decide footer text color)
	$wp_customize->add_setting( 'switch_graphics_content_bg', array(
		'default'           => '#ffffff',
		'sanitize_callback' => 'sanitize_hex_color',
		'transport'         => 'postMessage',
	) );
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'switch_graphics_content_bg', array(
		'label'       => __( 'Content / footer area background', 'switch-graphics' ),
		'description' => __( 'Footer text turns white on dark, black on light.', 'switch-graphics' ),
		'section'     => 'switch_graphics_footer',
	) ) );
}

add_action( 'customize_register', 'switch_graphics_customize_register' );

/**
 * Sanitize rgba string
 */
function switch_graphics_sanitize_rgba( $value ) {
	if ( preg_match( '/rgba?\s*\(\s*\d+\s*,\s*\d+\s*,\s*\d+\s*(,\s*[\d.]+\s*)?\)/', $value ) ) {
		return $value;
	}
	return 'rgba(0,0,0,0.25)';
}

/**
 * Output customizer CSS (header gradient, menu icon, footer text, body bg)
 */
function switch_graphics_customizer_css() {
	$header_top    = get_theme_mod( 'switch_graphics_header_gradient_top', '#000000' );
	$header_bottom = get_theme_mod( 'switch_graphics_header_gradient_bottom', 'rgba(0,0,0,0.25)' );
	$menu_from     = get_theme_mod( 'switch_graphics_menu_fill_from', '#e85d04' );
	$menu_to       = get_theme_mod( 'switch_graphics_menu_fill_to', '#dc2f02' );
	$menu_outline  = get_theme_mod( 'switch_graphics_menu_outline', '#323232' );
	$content_bg    = get_theme_mod( 'switch_graphics_content_bg', '#ffffff' );

	$footer_light = switch_graphics_is_color_dark( $content_bg );

	$css = sprintf(
		'.site-header { background: linear-gradient(to bottom, %1$s 0%%, %2$s 100%%); }',
		esc_attr( $header_top ),
		esc_attr( $header_bottom )
	);

	$css .= sprintf(
		'.menu-toggle .bar { background: linear-gradient(90deg, %1$s, %2$s); filter: drop-shadow(0 0 0 1px %3$s); -webkit-filter: drop-shadow(0 0 0 1px %3$s); }',
		esc_attr( $menu_from ),
		esc_attr( $menu_to ),
		esc_attr( $menu_outline )
	);

	$css .= sprintf(
		'body, #content, .site-main { background: %1$s; }',
		esc_attr( $content_bg )
	);

	$css .= $footer_light
		? '.site-footer { color: #fff; } .site-footer .copyright { color: #fff; }'
		: '.site-footer { color: #000; } .site-footer .copyright { color: #000; }';

	echo '<style id="switch-graphics-customizer">' . $css . '</style>';
}
add_action( 'wp_head', 'switch_graphics_customizer_css', 100 );

/**
 * Determine if hex color is dark (for footer text contrast)
 */
function switch_graphics_is_color_dark( $hex ) {
	$hex = ltrim( $hex, '#' );
	if ( strlen( $hex ) === 3 ) {
		$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
	}
	$r = hexdec( substr( $hex, 0, 2 ) );
	$g = hexdec( substr( $hex, 2, 2 ) );
	$b = hexdec( substr( $hex, 4, 2 ) );
	$luma = ( 0.299 * $r + 0.587 * $g + 0.114 * $b ) / 255;
	return $luma < 0.5;
}

/**
 * Customizer preview script
 */
function switch_graphics_customize_preview_js() {
	wp_enqueue_script(
		'switch-graphics-customizer',
		SWITCH_GRAPHICS_URI . '/js/customizer.js',
		array( 'customize-preview' ),
		SWITCH_GRAPHICS_VERSION,
		true
	);
}
add_action( 'customize_preview_init', 'switch_graphics_customize_preview_js' );
