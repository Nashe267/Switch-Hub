# Switch Graphics WordPress Theme

Minimal, full-screen WordPress theme matching the Switch Graphics layout: customizable header gradient, logo, burger menu (fill + outline), and adaptive footer text. Body area is full-screen for pages and shortcodes.

## Installation

1. Zip the `switch-graphics` folder (so the zip contains `switch-graphics/style.css`, `switch-graphics/functions.php`, etc.).
2. In WordPress: **Appearance → Themes → Add New → Upload Theme** and choose the zip.
3. Activate **Switch Graphics**.

## Customizer (Appearance → Customize)

- **Header**
  - **Header gradient (top)** — Top color of the header gradient (default: black).
  - **Header gradient (bottom)** — Bottom color; use `rgba(0,0,0,0.25)` for black at 25% opacity.
  - **Logo** — Upload your logo image (replaces the text logo).

- **Menu icon (burger)**
  - **Menu icon fill (gradient start/end)** — Fill gradient for the three lines.
  - **Menu icon outline color** — Outline around the burger lines.

- **Footer**
  - **Copyright text** — e.g. `2026 © Designed & Powered By: Switch Graphics (Pty) Ltd`. Supports bold via HTML.
  - **Content / footer area background** — Background for the main area; footer text automatically switches to **white** on dark and **black** on light (no solid bar).

## Menu

Assign a menu to **Primary Menu** under **Appearance → Menus** and assign it to “Primary Menu”. The burger icon toggles the dropdown.

## Requirements

- WordPress 5.0+
- PHP 7.4+
