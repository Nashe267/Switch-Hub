<?php
/**
 * Footer template — text only, no solid bar. Color adapts to background.
 *
 * @package Switch_Graphics
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$copyright = get_theme_mod( 'switch_graphics_copyright', '2026 © Designed & Powered By: Switch Graphics (Pty) Ltd' );
$content_bg = get_theme_mod( 'switch_graphics_content_bg', '#ffffff' );
$footer_class = switch_graphics_is_color_dark( $content_bg ) ? 'copyright-light' : 'copyright-dark';
?>
<footer id="colophon" class="site-footer <?php echo esc_attr( $footer_class ); ?>">
	<p class="copyright"><?php echo wp_kses_post( $copyright ); ?></p>
</footer>
<?php wp_footer(); ?>
</body>
</html>
